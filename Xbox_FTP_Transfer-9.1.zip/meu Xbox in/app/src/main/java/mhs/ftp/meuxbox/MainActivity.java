package mhs.ftp.meuxbox1;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.documentfile.provider.DocumentFile;

import org.apache.commons.net.ftp.FTPClient;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private EditText editIp;
    private RadioGroup groupStorage;
    private RadioButton radioUsb1;
    private ProgressBar progressIndividual, progressTotal;
    private TextView tvCurrentFile, tvPctIndividual, tvPctTotal, tvFileCount, tvQueueStatus;
    private Button btnSelectFolder, btnTestarConexao, btnPauseResume, btnCancelarTransferencia;

    private ImageView imgCurrentGame;
    private TextView tvCurrentGameName;

    private static final int REQUEST_CODE_TREE = 999;

    private static final String PREFS_NAME = "XboxPrefs";
    private static final String PREF_IP = "last_ip";
    private static final String PREF_USER = "ftp_user";
    private static final String PREF_PASS = "ftp_pass";
    private static final String PREF_PORT = "ftp_port";
    private static final String PREF_AURORA_USER = "aurora_user";
    private static final String PREF_AURORA_PASS = "aurora_pass";
    private static final String PREF_AURORA_SEM_LOGIN = "aurora_sem_login";

    private String currentTitleId = null;
    private String currentGameName = null;

    private ExecutorService executor = Executors.newFixedThreadPool(4);
    private Handler mainHandler = new Handler(Looper.getMainLooper());

    // ---- Ligação com o TransferService (a transferência roda nele, não na Activity) ----
    private TransferService transferService;
    private boolean serviceBound = false;

    /** Um jogo aguardando para ser enviado ao TransferService assim que ele estiver vinculado (bound). */
    private static class PendingJob {
        DocumentFile rootDir;
        String xexDest, titleIdMarker, nomeFallback;
        PendingJob(DocumentFile rootDir, String xexDest, String titleIdMarker, String nomeFallback) {
            this.rootDir = rootDir;
            this.xexDest = xexDest;
            this.titleIdMarker = titleIdMarker;
            this.nomeFallback = nomeFallback;
        }
    }

    // Fila local: guarda jogos escolhidos antes do TransferService estar vinculado (bound).
    // Depois de conectado, cada item é repassado para a fila de verdade dentro do serviço.
    private final List<PendingJob> filaPendente = new ArrayList<>();

    private final ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            TransferService.LocalBinder binder = (TransferService.LocalBinder) service;
            transferService = binder.getService();
            serviceBound = true;
            transferService.setListener(progressListener);

            if (transferService.isTransferEmAndamento() || transferService.getTamanhoFila() > 0) {
                btnPauseResume.setVisibility(View.VISIBLE);
                btnPauseResume.setText(transferService.isPausado() ? R.string.btn_retomar : R.string.btn_pausar);
                btnCancelarTransferencia.setVisibility(View.VISIBLE);
                btnCancelarTransferencia.setEnabled(true);
            }

            flushFilaPendente();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            serviceBound = false;
            transferService = null;
        }
    };

    private final TransferService.ProgressListener progressListener = new TransferService.ProgressListener() {
        @Override
        public void onStatus(String status) {
            runOnUiThread(() -> {
                if (status != null) tvCurrentFile.setText(status);
            });
        }

        @Override
        public void onFileCount(int done, int total) {
            runOnUiThread(() -> tvFileCount.setText(getString(R.string.label_arquivos_count_fmt, done, total)));
        }

        @Override
        public void onProgress(int individualPct, int totalPct) {
            runOnUiThread(() -> {
                progressIndividual.setProgress(individualPct);
                tvPctIndividual.setText(individualPct + "%");
                progressTotal.setProgress(totalPct);
                tvPctTotal.setText(totalPct + "%");
            });
        }

        @Override
        public void onGameInfo(String gameName, String titleId) {
            runOnUiThread(() -> {
                if (gameName != null) {
                    currentGameName = gameName;
                    currentTitleId = titleId;
                    tvCurrentGameName.setText(gameName);
                    if (titleId != null) {
                        imgCurrentGame.setTag(titleId);
                        carregarImagemComCache(titleId, "http://xboxunity.net/Resources/Lib/Icon.php?tid=" + titleId, imgCurrentGame);
                    }
                }
            });
        }

        @Override
        public void onQueueChanged(int restantesNaFila) {
            runOnUiThread(() -> {
                if (restantesNaFila <= 0) {
                    tvQueueStatus.setVisibility(View.GONE);
                } else {
                    tvQueueStatus.setVisibility(View.VISIBLE);
                    tvQueueStatus.setText(getString(R.string.label_fila_aguardando_fmt, restantesNaFila));
                }
            });
        }

        @Override
        public void onFinished(boolean success, String errorMsg) {
            runOnUiThread(() -> {
                btnSelectFolder.setEnabled(true);
                if (transferService == null || !transferService.isTransferEmAndamento()) {
                    btnPauseResume.setVisibility(View.GONE);
                    btnPauseResume.setText(R.string.btn_pausar);
                    btnCancelarTransferencia.setVisibility(View.GONE);
                }
                if (success) {
                    tocarSom(R.raw.sucesso);
                    Toast.makeText(MainActivity.this, R.string.toast_transferencia_concluida, Toast.LENGTH_LONG).show();
                } else if (errorMsg != null) {
                    tocarSom(R.raw.erro);
                    new AlertDialog.Builder(MainActivity.this)
                        .setTitle(R.string.dialog_transferencia_abortada_title)
                        .setMessage(getString(R.string.dialog_transferencia_abortada_message_fmt, errorMsg))
                        .setPositiveButton(R.string.action_ok, null)
                        .setCancelable(false)
                        .show();
                }
            });
        }

        @Override
        public void onCancelled() {
            runOnUiThread(() -> {
                btnSelectFolder.setEnabled(true);
                btnPauseResume.setVisibility(View.GONE);
                btnPauseResume.setText(R.string.btn_pausar);
                btnCancelarTransferencia.setVisibility(View.GONE);
                btnCancelarTransferencia.setEnabled(true);
                Toast.makeText(MainActivity.this, R.string.toast_transferencia_cancelada, Toast.LENGTH_LONG).show();
            });
        }

        @Override
        public void onAskAuroraRestart(TransferService.AuroraDecisionCallback callback) {
            runOnUiThread(() -> {
                new AlertDialog.Builder(MainActivity.this)
                    .setTitle(R.string.dialog_aurora_travado_title)
                    .setMessage(R.string.dialog_aurora_travado_message)
                    .setPositiveButton(R.string.btn_reiniciar_agora, (dialog, which) -> callback.onDecision(1))
                    .setNeutralButton(R.string.btn_reiniciar_sempre, (dialog, which) -> callback.onDecision(2))
                    .setNegativeButton(R.string.action_cancelar, (dialog, which) -> callback.onDecision(0))
                    .setCancelable(false)
                    .show();
            });
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        GameDatabase.inicializar(this);

        editIp = findViewById(R.id.edit_ip);
        groupStorage = findViewById(R.id.group_storage);
        radioUsb1 = findViewById(R.id.radio_usb1);
        progressIndividual = findViewById(R.id.progress_individual);
        progressTotal = findViewById(R.id.progress_total);
        tvCurrentFile = findViewById(R.id.tv_current_file);
        tvPctIndividual = findViewById(R.id.tv_pct_individual);
        tvPctTotal = findViewById(R.id.tv_pct_total);
        tvFileCount = findViewById(R.id.tv_file_count);
        tvQueueStatus = findViewById(R.id.tv_queue_status);
        btnSelectFolder = findViewById(R.id.btn_select_folder);
        btnTestarConexao = findViewById(R.id.btn_testar_conexao);
        btnPauseResume = findViewById(R.id.btn_pause_resume);
        btnCancelarTransferencia = findViewById(R.id.btn_cancelar_transferencia);

        imgCurrentGame = findViewById(R.id.img_current_game);
        tvCurrentGameName = findViewById(R.id.tv_current_game_name);

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        editIp.setText(prefs.getString(PREF_IP, ""));

        verificarPermissoes();

        Button btnAbrirJogos = findViewById(R.id.btn_abrir_jogos);
        if (btnAbrirJogos != null) {
            btnAbrirJogos.setOnClickListener(v -> {
                getSupportFragmentManager().beginTransaction()
                    .replace(android.R.id.content, new MeusJogosFragment())
                    .addToBackStack(null)
                    .commit();
            });
        }

        btnSelectFolder.setOnClickListener(v -> {
            String ipDigitado = editIp.getText().toString().trim();
            if (ipDigitado.isEmpty()) {
                Toast.makeText(this, R.string.toast_digite_ip, Toast.LENGTH_SHORT).show();
                return;
            }
            prefs.edit().putString(PREF_IP, ipDigitado).apply();

            currentGameName = null;
            currentTitleId = null;
            tvCurrentGameName.setText(R.string.status_aguardando_analise);
            imgCurrentGame.setImageResource(android.R.drawable.ic_menu_gallery);

            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            startActivityForResult(intent, REQUEST_CODE_TREE);
        });

        btnTestarConexao.setOnClickListener(v -> testarConexao());

        btnPauseResume.setOnClickListener(v -> {
            if (transferService == null) return;
            if (transferService.isPausado()) {
                transferService.retomarTransferencia();
                btnPauseResume.setText(R.string.btn_pausar);
            } else {
                transferService.pausarTransferencia();
                btnPauseResume.setText(R.string.btn_retomar);
            }
        });

        btnCancelarTransferencia.setOnClickListener(v -> {
            if (transferService == null) return;
            new AlertDialog.Builder(MainActivity.this)
                .setTitle(R.string.dialog_cancelar_titulo)
                .setMessage(R.string.dialog_cancelar_mensagem)
                .setPositiveButton(R.string.dialog_cancelar_confirmar, (dialog, which) -> {
                    btnCancelarTransferencia.setEnabled(false);
                    transferService.cancelarTransferencia();
                })
                .setNegativeButton(R.string.dialog_cancelar_negativo, null)
                .show();
        });

        boolean primeiroUso = prefs.getBoolean("primeiro_uso", true);
        if (primeiroUso) {
            mostrarTutorial();
            prefs.edit().putBoolean("primeiro_uso", false).apply();
        }

        Button btnInfo = findViewById(R.id.btn_info_app);
        if (btnInfo != null) {
            btnInfo.setOnClickListener(v -> mostrarInfoCreditos());
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        // Tenta se conectar a um TransferService que já esteja rodando (transferência em andamento).
        // Flag 0 (sem BIND_AUTO_CREATE) faz com que NADA seja criado se não houver transferência ativa,
        // evitando uma notificação "fantasma" quando o app é apenas aberto normalmente.
        Intent intent = new Intent(this, TransferService.class);
        bindService(intent, serviceConnection, 0);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (serviceBound) {
            if (transferService != null) {
                transferService.setListener(null);
            }
            unbindService(serviceConnection);
            serviceBound = false;
            transferService = null;
        }
    }

    private void exibirInfoDoJogo(String titleId) {
        currentTitleId = titleId;
        currentGameName = GameDatabase.getNomeDoJogo(titleId);
        String url = "http://xboxunity.net/Resources/Lib/Icon.php?tid=" + titleId;

        runOnUiThread(() -> {
            tvCurrentGameName.setText(currentGameName);
            imgCurrentGame.setTag(titleId);
            carregarImagemComCache(titleId, url, imgCurrentGame);
        });
    }

    private void exibirInfoDoJogoXex(String nomePasta) {
        currentTitleId = null;
        currentGameName = getString(R.string.game_name_xex_fmt, nomePasta);
        runOnUiThread(() -> {
            tvCurrentGameName.setText(currentGameName);
            imgCurrentGame.setImageResource(android.R.drawable.ic_menu_gallery);
        });
    }

    private void carregarImagemComCache(String titleId, String urlStr, ImageView imageView) {
        File cacheDir = new File(getCacheDir(), "xbox_covers");
        if (!cacheDir.exists()) cacheDir.mkdirs();
        File imageFile = new File(cacheDir, titleId + ".jpg");

        if (imageFile.exists()) {
            executor.execute(() -> {
                Bitmap bitmap = decodificarReduzido(imageFile.getAbsolutePath(), 200, 200);
                mainHandler.post(() -> {
                    if (bitmap != null && imageView.getTag() != null && imageView.getTag().equals(titleId)) {
                        imageView.setImageBitmap(bitmap);
                    }
                });
            });
            return;
        }

        executor.execute(() -> {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(urlStr);
                conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(3000);
                conn.connect();

                if (conn.getResponseCode() == 200) {
                    // try-with-resources: garante que input/output fecham mesmo se a conexão
                    // cair no meio do download (evita vazamento de file descriptors em wifi
                    // instável, que pode acumular e travar o app com "Too many open files").
                    try (InputStream input = conn.getInputStream();
                         FileOutputStream output = new FileOutputStream(imageFile)) {
                        byte[] buffer = new byte[1024];
                        int bytesRead;
                        while ((bytesRead = input.read(buffer)) != -1) {
                            output.write(buffer, 0, bytesRead);
                        }
                    }

                    Bitmap bitmap = decodificarReduzido(imageFile.getAbsolutePath(), 200, 200);
                    mainHandler.post(() -> {
                        if (bitmap != null && imageView.getTag() != null && imageView.getTag().equals(titleId)) {
                            imageView.setImageBitmap(bitmap);
                        }
                    });
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (conn != null) conn.disconnect();
            }
        });
    }

    /**
     * Decodifica uma imagem já reduzida para próximo de targetW x targetH, em vez de carregar
     * em resolução original (algumas capas do Archive.org passam de 1000px de largura).
     */
    private Bitmap decodificarReduzido(String path, int targetW, int targetH) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, bounds);

            int sampleSize = 1;
            int largura = bounds.outWidth, altura = bounds.outHeight;
            while ((largura / (sampleSize * 2)) >= targetW && (altura / (sampleSize * 2)) >= targetH) {
                sampleSize *= 2;
            }

            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = sampleSize;
            return BitmapFactory.decodeFile(path, options);
        } catch (Exception e) {
            return null;
        }
    }

    private void tocarSom(int resId) {
        try {
            MediaPlayer mp = new MediaPlayer();
            android.media.AudioAttributes attributes = new android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION_EVENT)
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            mp.setAudioAttributes(attributes);
            android.content.res.AssetFileDescriptor afd = getResources().openRawResourceFd(resId);
            mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            mp.setVolume(1.0f, 1.0f);
            mp.prepare();
            mp.setOnCompletionListener(MediaPlayer::release);
            mp.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_TREE && resultCode == RESULT_OK && data != null) {
            DocumentFile root = DocumentFile.fromTreeUri(this, data.getData());
            if (root != null) {
                try {
                    getContentResolver().takePersistableUriPermission(data.getData(),
                            Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                } catch (Exception ignored) {}

                btnSelectFolder.setEnabled(false);
                tvCurrentFile.setText(R.string.status_procurando_executaveis);
                verificarTipoEIniciar(root);
            }
        }
    }

    private DocumentFile procurarDefaultXex(DocumentFile dir, int depth) {
        if (depth > 3 || dir == null) return null;
        DocumentFile[] files = dir.listFiles();
        if (files == null) return null;

        for (DocumentFile f : files) {
            if (f.isFile() && f.getName() != null && f.getName().equalsIgnoreCase("default.xex")) {
                return f;
            }
        }
        for (DocumentFile f : files) {
            if (f.isDirectory()) {
                DocumentFile found = procurarDefaultXex(f, depth + 1);
                if (found != null) return found;
            }
        }
        return null;
    }

    private boolean contemXexProfundo(DocumentFile dir, int depth) {
        if (depth > 3 || dir == null) return false;
        DocumentFile[] files = dir.listFiles();
        if (files == null) return false;
        for (DocumentFile f : files) {
            if (f.isFile() && f.getName() != null && f.getName().toLowerCase().endsWith(".xex")) return true;
        }
        for (DocumentFile f : files) {
            if (f.isDirectory() && contemXexProfundo(f, depth + 1)) return true;
        }
        return false;
    }

    private void verificarTipoEIniciar(DocumentFile rootDir) {
        new Thread(() -> {
            boolean temXex = contemXexProfundo(rootDir, 0);
            String titleIdEncontrado = null;

            if (temXex) {
                DocumentFile defaultXex = procurarDefaultXex(rootDir, 0);
                if (defaultXex != null) {
                    titleIdEncontrado = XexParser.getTitleId(MainActivity.this, defaultXex);
                }
            }

            final String finalTitleId = titleIdEncontrado;

            runOnUiThread(() -> {
                if (temXex) {
                    if (finalTitleId != null) {
                        exibirInfoDoJogo(finalTitleId);
                    } else {
                        exibirInfoDoJogoXex(rootDir.getName());
                    }

                    new AlertDialog.Builder(MainActivity.this)
                        .setTitle(R.string.dialog_xex_detectado_title)
                        .setMessage(R.string.dialog_xex_detectado_message)
                        .setPositiveButton(R.string.btn_pasta_jogos, (dialog, which) -> {
                            adicionarJogoNaFila(rootDir, "Games", finalTitleId);
                        })
                        .setNegativeButton(R.string.btn_pasta_apps, (dialog, which) -> {
                            adicionarJogoNaFila(rootDir, "Apps", finalTitleId);
                        })
                        .setNeutralButton(R.string.action_cancelar, (dialog, which) -> {
                            btnSelectFolder.setEnabled(true);
                            tvCurrentFile.setText(R.string.status_aguardando);
                            tvCurrentGameName.setText(R.string.default_no_game_selected);
                        })
                        .setCancelable(false)
                        .show();
                } else {
                    adicionarJogoNaFila(rootDir, null, null);
                }
            });
        }).start();
    }

    /**
     * Adiciona o jogo escolhido à fila de transferência (através do TransferService, um
     * Foreground Service, garantindo que ela continue mesmo se o app for para segundo plano).
     * Diferente da versão anterior, isso NÃO bloqueia o botão "Selecionar Pasta": o usuário
     * pode continuar escolhendo mais jogos, que entram na fila e são enviados um após o outro.
     */
    private void adicionarJogoNaFila(DocumentFile rootDir, String xexDest, String titleIdMarker) {
        String nomeFallback = currentGameName != null ? currentGameName : rootDir.getName();
        PendingJob job = new PendingJob(rootDir, xexDest, titleIdMarker, nomeFallback);

        tvCurrentFile.setText(R.string.status_preparando_envio);
        btnSelectFolder.setEnabled(true);
        btnPauseResume.setVisibility(View.VISIBLE);
        btnPauseResume.setText(R.string.btn_pausar);
        btnCancelarTransferencia.setVisibility(View.VISIBLE);
        btnCancelarTransferencia.setEnabled(true);

        Intent svcIntent = new Intent(this, TransferService.class);
        ContextCompat.startForegroundService(this, svcIntent);

        if (serviceBound && transferService != null) {
            enviarJobParaServico(job);
        } else {
            filaPendente.add(job);
            bindService(svcIntent, serviceConnection, Context.BIND_AUTO_CREATE);
        }
    }

    /** Repassa todos os jogos que estavam esperando o TransferService conectar (bind). */
    private void flushFilaPendente() {
        if (transferService == null || filaPendente.isEmpty()) return;
        for (PendingJob job : filaPendente) {
            enviarJobParaServico(job);
        }
        filaPendente.clear();
    }

    /**
     * Lê a porta FTP configurada nas preferências (padrão: 21). Se o valor salvo
     * estiver vazio ou não for um número válido de porta (1-65535), cai no padrão.
     */
    private int obterPortaFtp(SharedPreferences prefs) {
        String portaStr = prefs.getString(PREF_PORT, "21");
        try {
            int porta = Integer.parseInt(portaStr.trim());
            return (porta > 0 && porta <= 65535) ? porta : 21;
        } catch (Exception e) {
            return 21;
        }
    }

    private void enviarJobParaServico(PendingJob job) {
        String ip = editIp.getText().toString().trim();
        String storage = ((RadioButton) findViewById(groupStorage.getCheckedRadioButtonId())).getText().toString();
        String basePath = "/" + storage;

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String ftpUser = prefs.getString(PREF_USER, "xbox");
        String ftpPass = prefs.getString(PREF_PASS, "xbox");
        int ftpPort = obterPortaFtp(prefs);

        transferService.adicionarNaFila(job.rootDir, job.xexDest, job.titleIdMarker,
                ip, ftpUser, ftpPass, ftpPort, basePath, job.nomeFallback);
    }

    /**
     * Testa a conexão FTP com o Xbox (conecta, tenta logar e desconecta) sem disparar
     * nenhuma transferência. Útil para verificar o IP e usuário/senha antes de enviar um jogo.
     */
    private void testarConexao() {
        String ip = editIp.getText().toString().trim();
        if (ip.isEmpty()) {
            Toast.makeText(this, R.string.toast_digite_ip, Toast.LENGTH_SHORT).show();
            return;
        }

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String ftpUser = prefs.getString(PREF_USER, "xbox");
        String ftpPass = prefs.getString(PREF_PASS, "xbox");
        int ftpPort = obterPortaFtp(prefs);

        btnTestarConexao.setEnabled(false);
        String statusAnterior = tvCurrentFile.getText().toString();
        tvCurrentFile.setText(R.string.status_testando_conexao);

        executor.execute(() -> {
            FTPClient ftp = new FTPClient();
            String resultadoMsg;
            boolean sucesso = false;
            boolean usb1Conectado = false;
            try {
                ftp.setConnectTimeout(5000);
                ftp.setDefaultTimeout(5000);
                ftp.connect(ip, ftpPort);
                ftp.setSoTimeout(5000);
                if (ftp.login(ftpUser, ftpPass)) {
                    sucesso = true;
                    resultadoMsg = getString(R.string.toast_conexao_ok_fmt, ip);
                    // Aproveita a conexão já aberta para checar se existe um pendrive
                    // USB1 plugado no Xbox, e assim decidir se mostramos essa opção.
                    usb1Conectado = ftp.changeWorkingDirectory("/Usb1");
                } else {
                    resultadoMsg = getString(R.string.toast_conexao_falha_login);
                }
            } catch (SocketTimeoutException e) {
                resultadoMsg = getString(R.string.toast_conexao_falha_timeout);
            } catch (Exception e) {
                resultadoMsg = getString(R.string.toast_conexao_falha_generica_fmt, e.getMessage());
            } finally {
                try { if (ftp.isConnected()) ftp.disconnect(); } catch (Exception ignored) {}
            }

            final String finalMsg = resultadoMsg;
            final boolean finalSucesso = sucesso;
            final boolean finalUsb1Conectado = usb1Conectado;
            mainHandler.post(() -> {
                btnTestarConexao.setEnabled(true);
                tvCurrentFile.setText(statusAnterior);
                Toast.makeText(MainActivity.this, finalMsg, finalSucesso ? Toast.LENGTH_SHORT : Toast.LENGTH_LONG).show();

                // Conexão confirmada: salva o IP agora, sem precisar esperar o usuário
                // clicar em "Selecionar Pasta" para liberar o acesso (ex: abrir "Meus Jogos").
                if (finalSucesso) {
                    prefs.edit().putString(PREF_IP, ip).apply();

                    if (finalUsb1Conectado) {
                        radioUsb1.setVisibility(View.VISIBLE);
                    } else {
                        radioUsb1.setVisibility(View.GONE);
                        if (radioUsb1.isChecked()) {
                            RadioButton radioHdd = findViewById(R.id.radio_hdd);
                            if (radioHdd != null) radioHdd.setChecked(true);
                        }
                    }
                }
            });
        });
    }

    private void verificarPermissoes() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
            }
        }
    }

    /**
     * Calcula a largura ideal para diálogos: 90% da tela no celular, mas nunca maior que
     * dialog_max_width (definido em dimens.xml e maior em values-sw600dp/sw840dp). Isso evita
     * diálogos gigantes e esticados em tablets e telas "desktop" Android.
     */
    private int calcularLarguraDialogo() {
        int largura90 = (int) (getResources().getDisplayMetrics().widthPixels * 0.90);
        int larguraMaxima = getResources().getDimensionPixelSize(R.dimen.dialog_max_width);
        return Math.min(largura90, larguraMaxima);
    }

    private void mostrarTutorial() {
        android.app.Dialog dialog = new android.app.Dialog(this);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_tutorial);
        dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setCancelable(false);

        int width = calcularLarguraDialogo();
        dialog.getWindow().setLayout(width, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);

        Button btnEntendi = dialog.findViewById(R.id.btn_entendi_tutorial);
        btnEntendi.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private void mostrarInfoCreditos() {
        android.app.Dialog dialog = new android.app.Dialog(this);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_info_creditos);
        dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));

        int width = calcularLarguraDialogo();
        dialog.getWindow().setLayout(width, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);

        EditText editUser = dialog.findViewById(R.id.edit_ftp_user);
        EditText editPass = dialog.findViewById(R.id.edit_ftp_pass);
        EditText editPort = dialog.findViewById(R.id.edit_ftp_port);
        CheckBox chkAuroraSemLogin = dialog.findViewById(R.id.chk_aurora_sem_login);
        EditText editAuroraUser = dialog.findViewById(R.id.edit_aurora_user);
        EditText editAuroraPass = dialog.findViewById(R.id.edit_aurora_pass);
        TextView devTitulo = dialog.findViewById(R.id.tv_cred_dev_titulo);
        TextView devNome = dialog.findViewById(R.id.tv_cred_dev_nome);
        TextView gtTitulo = dialog.findViewById(R.id.tv_cred_gt_titulo);
        TextView gtNome = dialog.findViewById(R.id.tv_cred_gt_nome);
        TextView agradecimentos = dialog.findViewById(R.id.tv_cred_agradecimentos);
        Button btnFechar = dialog.findViewById(R.id.btn_fechar_info);

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        editUser.setText(prefs.getString(PREF_USER, "xbox"));
        editPass.setText(prefs.getString(PREF_PASS, "xbox"));
        editPort.setText(prefs.getString(PREF_PORT, "21"));

        boolean auroraSemLogin = prefs.getBoolean(PREF_AURORA_SEM_LOGIN, false);
        editAuroraUser.setText(prefs.getString(PREF_AURORA_USER, "xboxhttp"));
        editAuroraPass.setText(prefs.getString(PREF_AURORA_PASS, "xboxhttp"));
        chkAuroraSemLogin.setChecked(auroraSemLogin);
        editAuroraUser.setEnabled(!auroraSemLogin);
        editAuroraPass.setEnabled(!auroraSemLogin);
        chkAuroraSemLogin.setOnCheckedChangeListener((btn, marcado) -> {
            editAuroraUser.setEnabled(!marcado);
            editAuroraPass.setEnabled(!marcado);
        });

        devTitulo.setText(R.string.credits_dev_titulo);
        devNome.setText(R.string.credits_dev_nome);
        gtTitulo.setText(R.string.credits_apis_titulo);
        gtNome.setText(R.string.credits_apis_lista);
        agradecimentos.setText(R.string.credits_rodape);

        btnFechar.setOnClickListener(v -> {
            // Se a porta digitada estiver vazia ou não for válida (1-65535), cai no
            // padrão 21 em vez de salvar algo que quebraria a conexão FTP.
            String portaDigitada = editPort.getText().toString().trim();
            String portaParaSalvar;
            try {
                int porta = Integer.parseInt(portaDigitada);
                portaParaSalvar = (porta > 0 && porta <= 65535) ? String.valueOf(porta) : "21";
            } catch (Exception e) {
                portaParaSalvar = "21";
            }

            prefs.edit()
                 .putString(PREF_USER, editUser.getText().toString().trim())
                 .putString(PREF_PASS, editPass.getText().toString().trim())
                 .putString(PREF_PORT, portaParaSalvar)
                 .putString(PREF_AURORA_USER, editAuroraUser.getText().toString().trim())
                 .putString(PREF_AURORA_PASS, editAuroraPass.getText().toString().trim())
                 .putBoolean(PREF_AURORA_SEM_LOGIN, chkAuroraSemLogin.isChecked())
                 .apply();
            Toast.makeText(MainActivity.this, R.string.toast_config_salvas, Toast.LENGTH_SHORT).show();
            dialog.dismiss();
        });
        dialog.show();
    }

    public static String bytesToHex(byte[] bytes) {
        char[] hexArray = "0123456789ABCDEF".toCharArray();
        char[] hexChars = new char[bytes.length * 2];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[j * 2 + 1] = hexArray[v & 0x0F];
        }
        return new String(hexChars);
    }
}