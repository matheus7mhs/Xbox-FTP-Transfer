package mhs.ftp.meuxbox1;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Guarda em disco o resultado do último escaneamento de jogos (por IP do Xbox), para que a
 * aba "Meus Jogos" abra instantaneamente mostrando o que já foi encontrado antes, em vez de
 * ter que escanear tudo de novo via FTP toda vez que a tela é aberta. O usuário ainda pode
 * forçar uma atualização a qualquer momento tocando em "Escanear Jogos do Xbox".
 */
public class GameCache {

    private static final String PASTA_CACHE = "game_cache";

    public static class CacheResult {
        public final List<ListarGames> jogos;
        public final long timestampMs;
        CacheResult(List<ListarGames> jogos, long timestampMs) {
            this.jogos = jogos;
            this.timestampMs = timestampMs;
        }
    }

    private static File arquivoParaIp(Context context, String ip) {
        File dir = new File(context.getFilesDir(), PASTA_CACHE);
        if (!dir.exists()) dir.mkdirs();
        String nomeSeguro = ip.replaceAll("[^a-zA-Z0-9]", "_");
        return new File(dir, "scan_" + nomeSeguro + ".json");
    }

    /** Salva a lista de jogos encontrados para este IP. Falha silenciosamente (cache é best-effort). */
    public static void salvar(Context context, String ip, List<ListarGames> jogos) {
        try {
            JSONObject raiz = new JSONObject();
            raiz.put("timestamp", System.currentTimeMillis());

            JSONArray array = new JSONArray();
            for (ListarGames g : jogos) {
                JSONObject o = new JSONObject();
                o.put("titleId", g.getTitleId());
                o.put("nome", g.getNome());
                o.put("caminhoFtp", g.getCaminhoFtp());
                o.put("tipoJogo", g.getTipoJogo());
                array.put(o);
            }
            raiz.put("games", array);

            File f = arquivoParaIp(context, ip);
            try (FileOutputStream fos = new FileOutputStream(f)) {
                fos.write(raiz.toString().getBytes(StandardCharsets.UTF_8));
            }
        } catch (Exception ignored) {
            // Cache é apenas uma otimização; se falhar, o próximo escaneamento manual resolve.
        }
    }

    /** Carrega o cache salvo para este IP, ou null se não existir/estiver corrompido. */
    public static CacheResult carregar(Context context, String ip) {
        File f = arquivoParaIp(context, ip);
        if (!f.exists()) return null;

        try (InputStream is = new FileInputStream(f)) {
            byte[] bytes = new byte[(int) f.length()];
            int lido = 0;
            while (lido < bytes.length) {
                int r = is.read(bytes, lido, bytes.length - lido);
                if (r == -1) break;
                lido += r;
            }
            String json = new String(bytes, 0, lido, StandardCharsets.UTF_8);

            JSONObject raiz = new JSONObject(json);
            long timestamp = raiz.optLong("timestamp", 0);
            JSONArray array = raiz.getJSONArray("games");

            List<ListarGames> lista = new ArrayList<>();
            for (int i = 0; i < array.length(); i++) {
                JSONObject o = array.getJSONObject(i);
                lista.add(new ListarGames(
                        o.optString("titleId", null),
                        o.optString("nome", null),
                        o.optString("caminhoFtp", null),
                        o.optString("tipoJogo", "XEX")
                ));
            }
            return new CacheResult(lista, timestamp);
        } catch (Exception e) {
            return null;
        }
    }
}
