package mhs.ftp.meuxbox1;

import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.documentfile.provider.DocumentFile;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class TransferService extends Service {

    public static final String CHANNEL_ID = "xbox_ftp_transfer";
    private static final int NOTIF_ID = 1001;
    private static final int LIMIAR_TENTATIVAS_AURORA = 5;
    private static final String PREFS_NAME = "XboxPrefs";
    private static final String PREF_AURORA_AUTO_RESTART = "aurora_auto_restart";

    private static final int AURORA_RESULT_NAO_TENTOU = 0;
    private static final int AURORA_RESULT_SUCESSO = 1;
    private static final int AURORA_RESULT_FALHOU = 2;
    private static final int AURORA_RESULT_RECUSADO = -1;

    private static volatile AuroraWebCallback pendingWebCallback;

    public static void reportarResultadoAuroraRestart(boolean ok) {
        AuroraWebCallback cb = pendingWebCallback;
        pendingWebCallback = null;
        if (cb != null) cb.onDone(ok);
    }

    public interface ProgressListener {
        void onStatus(String status);
        void onFileCount(int done, int total);
        void onProgress(int individualPct, int totalPct);
        void onGameInfo(String gameName, String titleId);
        void onFinished(boolean success, String errorMsg);
        void onCancelled();
        void onAskAuroraRestart(AuroraDecisionCallback callback);
        void onQueueChanged(int restantesNaFila);
    }

    public interface AuroraDecisionCallback {
        void onDecision(int decision);
    }

    public class LocalBinder extends Binder {
        TransferService getService() { return TransferService.this; }
    }

    private final IBinder binder = new LocalBinder();
    private volatile ProgressListener listener;
    private volatile boolean transferEmAndamento = false;

    private String lastStatus = "";
    private int lastFileDone = 0, lastFileTotal = 0;
    private int lastIndividualPct = 0, lastTotalPct = 0;
    private String lastGameName = null, lastTitleId = null;

    private NotificationManager notificationManager;
    private NotificationCompat.Builder notificationBuilder;

    private long totalBytesGlobal = 0;
    private long bytesEnviadosGlobal = 0;
    private int totalArquivos = 0;
    private int arquivosEnviados = 0;

    private static class FtpTask {
        DocumentFile localFile;
        String remotePath;
        FtpTask(DocumentFile f, String p) { localFile = f; remotePath = p; }
    }

    // ---- Fila de múltiplos jogos: cada job aguarda sua vez e é iniciado automaticamente
    // assim que o job anterior terminar (com sucesso ou falha). ----
    private static class TransferJob {
        DocumentFile rootDir;
        String xexDest, titleIdMarker, ip, ftpUser, ftpPass, basePath, nomeFallback;
        int ftpPort;
        TransferJob(DocumentFile rootDir, String xexDest, String titleIdMarker, String ip,
                    String ftpUser, String ftpPass, int ftpPort, String basePath, String nomeFallback) {
            this.rootDir = rootDir;
            this.xexDest = xexDest;
            this.titleIdMarker = titleIdMarker;
            this.ip = ip;
            this.ftpUser = ftpUser;
            this.ftpPass = ftpPass;
            this.ftpPort = ftpPort;
            this.basePath = basePath;
            this.nomeFallback = nomeFallback;
        }
    }

    private final java.util.concurrent.ConcurrentLinkedQueue<TransferJob> filaTransferencias = new java.util.concurrent.ConcurrentLinkedQueue<>();
    private int lastFilaRestante = 0;

    // ---- Pausar / retomar a transferência em andamento ----
    private volatile boolean pausado = false;
    private final Object pauseLock = new Object();

    // ---- Cancelar a transferência em andamento (definitivo, diferente de pausar) ----
    private volatile boolean cancelado = false;

    /** Usada internamente só pra sinalizar "pare tudo agora" vindo de dentro da leitura do
     * arquivo (aguardarSePausado); capturada separadamente no laço de tentativas pra não ser
     * tratada como uma falha de conexão comum (que tentaria reconectar). */
    private static class TransferenciaCanceladaException extends IOException {
        TransferenciaCanceladaException() { super("Transferência cancelada pelo usuário"); }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationManager.createNotificationChannel(
                    new NotificationChannel(CHANNEL_ID, getString(R.string.notif_channel_xbox_ftp), NotificationManager.IMPORTANCE_LOW));
        }
        notificationBuilder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentTitle(getString(R.string.notif_channel_xbox_ftp))
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(true);
        startForeground(NOTIF_ID, notificationBuilder.build());
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }

    public boolean isTransferEmAndamento() {
        return transferEmAndamento;
    }

    public void setListener(ProgressListener l) {
        this.listener = l;
        if (l != null) {
            l.onGameInfo(lastGameName, lastTitleId);
            l.onStatus(lastStatus);
            l.onFileCount(lastFileDone, lastFileTotal);
            l.onProgress(lastIndividualPct, lastTotalPct);
            l.onQueueChanged(lastFilaRestante);
        }
    }

    /** Quantos jobs ainda aguardam na fila (não conta o que está transferindo agora). */
    public int getTamanhoFila() {
        return filaTransferencias.size();
    }

    public boolean isPausado() {
        return pausado;
    }

    /** Pausa a transferência atual (ela retoma exatamente de onde parou, sem reenviar o arquivo do zero). */
    public void pausarTransferencia() {
        pausado = true;
        postStatus(getString(R.string.status_pausado));
    }

    public void retomarTransferencia() {
        synchronized (pauseLock) {
            pausado = false;
            pauseLock.notifyAll();
        }
        postStatus(getString(R.string.status_retomando));
    }

    /**
     * Cancela a transferência atual (se houver) e limpa toda a fila de jogos aguardando.
     * Diferente de pausar: é definitivo, não dá pra retomar depois. Se a transferência
     * estava pausada, acorda a thread na hora pra ela perceber o cancelamento imediatamente
     * em vez de ficar travada esperando um "retomar" que nunca vai vir.
     */
    public void cancelarTransferencia() {
        cancelado = true;
        filaTransferencias.clear();
        notificarFila();
        synchronized (pauseLock) {
            pausado = false;
            pauseLock.notifyAll();
        }
    }

    /** Bloqueia a thread de envio enquanto pausado=true; usado dentro da leitura do arquivo.
     * Também interrompe a transferência (lançando TransferenciaCanceladaException) assim que
     * cancelado=true, seja antes, durante ou depois de uma pausa. */
    private void aguardarSePausado() throws IOException {
        if (cancelado) throw new TransferenciaCanceladaException();
        try {
            synchronized (pauseLock) {
                while (pausado && !cancelado) {
                    pauseLock.wait(500);
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Transferência interrompida durante a pausa", e);
        }
        if (cancelado) throw new TransferenciaCanceladaException();
    }

    private void notificarFila() {
        lastFilaRestante = filaTransferencias.size();
        ProgressListener l = listener;
        if (l != null) l.onQueueChanged(lastFilaRestante);
    }

    private void postStatus(String s) {
        lastStatus = s;
        ProgressListener l = listener;
        if (l != null) l.onStatus(s);
    }

    private void postFileCount(int d, int t) {
        lastFileDone = d; lastFileTotal = t;
        ProgressListener l = listener;
        if (l != null) l.onFileCount(d, t);
    }

    private void postProgress(int i, int t) {
        lastIndividualPct = i; lastTotalPct = t;
        ProgressListener l = listener;
        if (l != null) l.onProgress(i, t);
    }

    private void postGameInfo(String nome, String tid) {
        lastGameName = nome; lastTitleId = tid;
        ProgressListener l = listener;
        if (l != null) l.onGameInfo(nome, tid);
    }

    /**
     * Adiciona um jogo à fila de transferência. Se nenhum outro job estiver rodando, ele
     * começa imediatamente; caso contrário, fica aguardando e é iniciado automaticamente
     * assim que os anteriores terminarem (com sucesso ou falha).
     */
    public void adicionarNaFila(DocumentFile rootDir, String xexDest, String titleIdMarker,
                                 String ip, String ftpUser, String ftpPass, int ftpPort, String basePath,
                                 String nomeFallback) {
        filaTransferencias.add(new TransferJob(rootDir, xexDest, titleIdMarker, ip, ftpUser, ftpPass, ftpPort, basePath, nomeFallback));
        notificarFila();
        if (!transferEmAndamento) {
            processarProximaDaFila();
        }
    }

    /** Pega o próximo job da fila e o executa; se a fila estiver vazia, encerra o serviço. */
    private void processarProximaDaFila() {
        TransferJob job = filaTransferencias.poll();
        notificarFila();
        if (job == null) {
            pausado = false;
            pararServico();
            return;
        }
        executarTransferencia(job);
    }

    private void executarTransferencia(TransferJob job) {
        DocumentFile rootDir = job.rootDir;
        String xexDest = job.xexDest;
        String titleIdMarker = job.titleIdMarker;
        String ip = job.ip;
        String ftpUser = job.ftpUser;
        String ftpPass = job.ftpPass;
        int ftpPort = job.ftpPort;
        String basePath = job.basePath;
        String nomeFallback = job.nomeFallback;

        transferEmAndamento = true;
        pausado = false;
        cancelado = false;

        totalBytesGlobal = 0;
        bytesEnviadosGlobal = 0;
        totalArquivos = 0;
        arquivosEnviados = 0;
        lastGameName = null;
        lastTitleId = null;
        postStatus(getString(R.string.status_preparando_envio));

        new Thread(() -> {
            List<FtpTask> tarefas = new ArrayList<>();

            if (xexDest != null) {
                String remoteRoot = basePath + "/" + xexDest + "/" + rootDir.getName();
                tarefas.add(new FtpTask(rootDir, remoteRoot));
                mapearRecursivoXEX(rootDir, remoteRoot, tarefas);
            } else {
                analisarPastaSTFS(rootDir, basePath, rootDir.getName(), tarefas);
            }

            String nomeParaNotificacao = (lastGameName != null) ? lastGameName : nomeFallback;
            String titleIdParaNotif = lastTitleId;

            if (tarefas.isEmpty()) {
                postStatus(getString(R.string.status_aguardando));
                transferEmAndamento = false;
                ProgressListener l = listener;
                if (l != null) l.onFinished(false, getString(R.string.toast_nenhum_arquivo));
                processarProximaDaFila();
                return;
            }

            iniciarNotificacao(nomeParaNotificacao, titleIdParaNotif);
            postFileCount(0, totalArquivos);

            int limiteTentativas = 60;
            int tentativasConsecutivas = 0;
            int taskIndex = 0;
            boolean transferenciaConcluida = false;
            boolean auroraRecusadoPeloUsuario = false;
            String ultimoErro = "";

            while (taskIndex < tarefas.size() && tentativasConsecutivas < limiteTentativas) {
                if (cancelado) break;
                FTPClient ftp = new FTPClient();
                try {
                    ftp.setConnectTimeout(30000);
                    ftp.setDefaultTimeout(60000);
                    ftp.connect(ip, ftpPort);
                    ftp.setSoTimeout(900000);
                    ftp.setDataTimeout(900000);
                    ftp.login(ftpUser, ftpPass);
                    ftp.setFileType(FTP.BINARY_FILE_TYPE);
                    ftp.enterLocalPassiveMode();
                    ftp.setBufferSize(1024 * 1024);
                    ftp.setControlKeepAliveTimeout(60); 
                    ftp.setControlKeepAliveReplyTimeout(10000);

                    while (taskIndex < tarefas.size()) {
                        aguardarSePausado();
                        FtpTask task = tarefas.get(taskIndex);
                        if (task.localFile.isDirectory()) {
                            criarDiretorioFTP(ftp, task.remotePath);
                        } else {
                            enviarArquivo(ftp, task.localFile, task.remotePath);
                            arquivosEnviados++;
                            postFileCount(arquivosEnviados, totalArquivos);
                        }
                        taskIndex++; 
                        tentativasConsecutivas = 0;
                    }

                    transferenciaConcluida = true;

                } catch (TransferenciaCanceladaException cancelada) {
                    // Cancelamento explícito do usuário: sai do laço de tentativas sem contar
                    // como falha de conexão (não tenta reconectar nem reinicia o Aurora).
                    break;
                } catch (Exception e) {
                    tentativasConsecutivas++;
                    ultimoErro = e.getMessage();
                    final int tentarMsg = tentativasConsecutivas;
                    e.printStackTrace();

                    postStatus(getString(R.string.status_conexao_instavel_fmt, tentarMsg, limiteTentativas));

                    if (!auroraRecusadoPeloUsuario && tentativasConsecutivas % LIMIAR_TENTATIVAS_AURORA == 0) {
                        int resultado = decidirEReiniciarAurora(ip);
                        if (resultado == AURORA_RESULT_SUCESSO) {
                            tentativasConsecutivas = 0;
                        } else if (resultado == AURORA_RESULT_RECUSADO) {
                            auroraRecusadoPeloUsuario = true;
                        }
                    }

                    try { Thread.sleep(5000); } catch (InterruptedException ignored) {}
                } finally {
                    try { if (ftp.isConnected()) ftp.disconnect(); } catch (Exception ignored) {}
                }
            }

            if (cancelado) {
                cancelado = false;
                pausado = false;
                finalizarNotificacaoCancelada(nomeParaNotificacao);
                postStatus(getString(R.string.status_cancelado));
                transferEmAndamento = false;
                filaTransferencias.clear();
                notificarFila();
                ProgressListener l = listener;
                if (l != null) l.onCancelled();
                pararServico();
                return;
            }

            if (transferenciaConcluida) {
                if (xexDest != null && titleIdMarker != null) {
                    FTPClient markerFtp = new FTPClient();
                    try {
                        markerFtp.connect(ip, ftpPort);
                        markerFtp.login(ftpUser, ftpPass);
                        String markerPath = basePath + "/" + xexDest + "/" + rootDir.getName() + "/mhs_id_" + titleIdMarker + ".txt";
                        markerFtp.storeFile(markerPath, new ByteArrayInputStream("MHS".getBytes()));
                    } catch (Exception ignored) {
                    } finally {
                        // Se storeFile() (ou connect/login) falhar, o disconnect() no final do try
                        // nunca rodava e a conexão ficava aberta. Movido pro finally.
                        try { if (markerFtp.isConnected()) markerFtp.disconnect(); } catch (Exception ignored2) {}
                    }
                }

                finalizarNotificacao(nomeParaNotificacao, true);
                postStatus(getString(R.string.status_finalizado));
                transferEmAndamento = false;
                ProgressListener l = listener;
                if (l != null) l.onFinished(true, null);
            } else {
                finalizarNotificacao(nomeParaNotificacao, false);
                postStatus(getString(R.string.status_falha_tentativas));
                transferEmAndamento = false;
                ProgressListener l = listener;
                if (l != null) l.onFinished(false, ultimoErro);
            }

            processarProximaDaFila();
        }).start();
    }

    private void pararServico() {
        stopForeground(STOP_FOREGROUND_DETACH);
        stopSelf();
    }

    private int decidirEReiniciarAurora(String ip) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean autoSempre = prefs.getBoolean(PREF_AURORA_AUTO_RESTART, false);

        if (autoSempre) {
            postStatus(getString(R.string.status_reiniciando_aurora));
            return reiniciarAuroraViaWebView(ip) ? AURORA_RESULT_SUCESSO : AURORA_RESULT_FALHOU;
        }

        ProgressListener ouvinteAtual = listener;
        if (ouvinteAtual == null) {
            return AURORA_RESULT_NAO_TENTOU;
        }

        CountDownLatch latchDecisao = new CountDownLatch(1);
        AtomicInteger decisao = new AtomicInteger(-1); 

        new Handler(Looper.getMainLooper()).post(() -> {
            ProgressListener l = listener;
            if (l == null) {
                latchDecisao.countDown();
                return;
            }
            l.onAskAuroraRestart(d -> {
                decisao.set(d);
                latchDecisao.countDown();
            });
        });

        try {
            latchDecisao.await(45, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {}

        int d = decisao.get();
        if (d == -1) return AURORA_RESULT_NAO_TENTOU; 
        if (d == 0) return AURORA_RESULT_RECUSADO; 
        if (d == 2) prefs.edit().putBoolean(PREF_AURORA_AUTO_RESTART, true).apply();

        postStatus(getString(R.string.status_reiniciando_aurora));
        return reiniciarAuroraViaWebView(ip) ? AURORA_RESULT_SUCESSO : AURORA_RESULT_FALHOU;
    }

    private boolean reiniciarAuroraViaWebView(String ip) {
        CountDownLatch latch = new CountDownLatch(1);
        AtomicBoolean sucesso = new AtomicBoolean(false);

        pendingWebCallback = ok -> {
            sucesso.set(ok);
            latch.countDown();
        };

        Intent activityIntent = new Intent(this, AuroraRestartActivity.class);
        activityIntent.putExtra(AuroraRestartActivity.EXTRA_IP, ip);
        activityIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_NO_HISTORY
                | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
        try {
            startActivity(activityIntent);
        } catch (Exception e) {
            Log.e("AuroraRestart", "Falha ao iniciar AuroraRestartActivity", e);
            pendingWebCallback = null;
            return false;
        }

        try {
            latch.await(90, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {}

        pendingWebCallback = null; 

        if (sucesso.get()) {
            try { Thread.sleep(20000); } catch (InterruptedException ignored) {}
        }
        return sucesso.get();
    }

    public interface AuroraWebCallback {
        void onDone(boolean sucesso);
    }

    private void mapearRecursivoXEX(DocumentFile dir, String remotePath, List<FtpTask> tarefas) {
        DocumentFile[] files = dir.listFiles();
        if (files == null) return;
        for (DocumentFile f : files) {
            String currentRemote = remotePath + "/" + f.getName();
            tarefas.add(new FtpTask(f, currentRemote));
            if (f.isDirectory()) {
                mapearRecursivoXEX(f, currentRemote, tarefas);
            } else {
                totalArquivos++;
                totalBytesGlobal += f.length();
            }
        }
    }

    private void analisarPastaSTFS(DocumentFile dir, String storageBase, String defaultFolderName, List<FtpTask> tarefas) {
        DocumentFile[] files = dir.listFiles();
        if (files == null) return;

        String godPathDaPastaAtual = null;
        boolean infosDoJogoJaExibidas = (lastGameName != null);

        for (DocumentFile f : files) {
            if (f.isFile()) {
                String[] info = readSTFSHeader(f);
                if (info != null) {
                    if (!infosDoJogoJaExibidas) {
                        postGameInfo(GameDatabase.getNomeDoJogo(info[0]), info[0]);
                        infosDoJogoJaExibidas = true;
                    }
                    if (info[1].equals("00007000")) {
                        godPathDaPastaAtual = storageBase + "/Content/0000000000000000/" + info[0] + "/00007000";
                        break;
                    }
                }
            }
        }

        for (DocumentFile f : files) {
            if (f.isDirectory()) {
                if (f.getName() != null && f.getName().endsWith(".data") && godPathDaPastaAtual != null) {
                    mapearRecursivoSTFS(f, godPathDaPastaAtual + "/" + f.getName(), tarefas);
                } else {
                    analisarPastaSTFS(f, storageBase, defaultFolderName + "/" + f.getName(), tarefas);
                }
            } else {
                String[] info = readSTFSHeader(f);
                if (info != null) {
                    String titleId = info[0];
                    String contentType = info[1];
                    String stfsPath = storageBase + "/Content/0000000000000000/" + titleId + "/" + contentType;
                    tarefas.add(new FtpTask(f, stfsPath + "/" + f.getName()));
                } else {
                    String fallbackPath = storageBase + "/Games/" + defaultFolderName;
                    tarefas.add(new FtpTask(f, fallbackPath + "/" + f.getName()));
                }
                totalArquivos++;
                totalBytesGlobal += f.length();
            }
        }
    }

    private void mapearRecursivoSTFS(DocumentFile dir, String remotePath, List<FtpTask> tarefas) {
        DocumentFile[] files = dir.listFiles();
        if (files == null) return;
        for (DocumentFile f : files) {
            if (f.isDirectory()) {
                mapearRecursivoSTFS(f, remotePath + "/" + f.getName(), tarefas);
            } else {
                tarefas.add(new FtpTask(f, remotePath + "/" + f.getName()));
                totalArquivos++;
                totalBytesGlobal += f.length();
            }
        }
    }

    private String[] readSTFSHeader(DocumentFile file) {
        try (InputStream is = getContentResolver().openInputStream(file.getUri())) {
            if (is == null) return null;
            byte[] h = new byte[0x364];
            if (is.read(h) >= 0x364) {
                String magic = new String(h, 0, 4);
                if (magic.equals("CON ") || magic.equals("PIRS") || magic.equals("LIVE")) {
                    return new String[]{ MainActivity.bytesToHex(Arrays.copyOfRange(h, 0x360, 0x364)),
                                         MainActivity.bytesToHex(Arrays.copyOfRange(h, 0x344, 0x348)) };
                }
            }
        } catch (Exception ignored) {}
        return null;
    }

    private void criarDiretorioFTP(FTPClient ftp, String dirPath) throws IOException {
        String[] folders = dirPath.split("/");
        String path = "";
        for (String folder : folders) {
            if (!folder.isEmpty()) {
                path += "/" + folder;
                ftp.makeDirectory(path);
            }
        }
    }

    // --- O CÓDIGO CORRIGIDO ESTÁ AQUI NESTE MÉTODO ---
    private void enviarArquivo(FTPClient ftp, DocumentFile file, String remotePath) throws Exception {
        String parent = remotePath.substring(0, remotePath.lastIndexOf('/'));
        criarDiretorioFTP(ftp, parent);

        long localSize = file.length();
        long remoteSize = -1; 

        // 1. Pergunta o tamanho de forma mais tolerante (Alguns Xbox respondem 213, outros 250)
        try {
            ftp.sendCommand("SIZE", remotePath);
            int replyCode = ftp.getReplyCode();
            if (replyCode == 213 || replyCode == 250) {
                String reply = ftp.getReplyString().trim();
                String[] parts = reply.split("\\s+");
                remoteSize = Long.parseLong(parts[parts.length - 1]);
            }
        } catch (Exception ignored) {}

        // 2. Se o tamanho for exato, pula
        if (remoteSize == localSize) {
            bytesEnviadosGlobal += localSize;
            atualizarUI(localSize, localSize, bytesEnviadosGlobal);
            postStatus("Verificado OK: " + file.getName());
            return; 
        }

        // 3. Se existe e o tamanho é diferente, tenta deletar. 
        // IMPORTANTE: Aqui tiramos o 'throw new IOException', pois o FTP do Xbox costuma travar na deleção.
        if (remoteSize >= 0) {
            postStatus("Substituindo arquivo: " + file.getName());
            try {
                ftp.deleteFile(remotePath); 
            } catch (Exception ignored) {} 
            // Ignoramos se falhar. O 'storeFile' vai forçar a sobrescrita do arquivo.
        }

        // 4. Envia o arquivo de forma direta, sem checagem pós-envio paranóica
        ftp.setRestartOffset(0);
        postStatus(getString(R.string.status_enviando_fmt, file.getName()));

        try (InputStream is = getContentResolver().openInputStream(file.getUri())) {
            if (is == null) throw new IOException("Falha ao ler arquivo local: " + file.getName());

            boolean sucesso = ftp.storeFile(remotePath, new InputStream() {
                long lidos = 0;
                @Override public int read() throws IOException {
                    aguardarSePausado();
                    int d = is.read();
                    if (d != -1) {
                        lidos++;
                        atualizarUI(lidos, localSize, bytesEnviadosGlobal + lidos);
                    }
                    return d;
                }
                @Override public int read(byte[] b, int o, int len) throws IOException {
                    aguardarSePausado();
                    int r = is.read(b, o, len);
                    if (r > 0) {
                        lidos += r;
                        atualizarUI(lidos, localSize, bytesEnviadosGlobal + lidos);
                    }
                    return r;
                }
            });

            // Se o upload falhar DE FATO aqui (conexão caiu, Xbox reiniciou), aí sim ele entra no esquema de reconectar e tentar de novo
            if (!sucesso) {
                throw new IOException("Falha na gravação final. Servidor respondeu: " + ftp.getReplyString());
            }

            bytesEnviadosGlobal += localSize;
        }
    }

    private long ultimoNotifyMs = 0;
    private int ultimoPctNotificado = -1;

    private void atualizarUI(long bytesArquivoAtual, long tamanhoTotalArquivoLocal, long totalBytesEnviadosAteMomento) {
        int pI = tamanhoTotalArquivoLocal > 0 ? (int) ((bytesArquivoAtual * 100) / tamanhoTotalArquivoLocal) : 0;
        int pT = totalBytesGlobal > 0 ? (int) ((totalBytesEnviadosAteMomento * 100) / totalBytesGlobal) : 0;

        if (pI > 100) pI = 100;
        if (pT > 100) pT = 100;

        postProgress(pI, pT);

        long agora = System.currentTimeMillis();
        boolean percentualMudou = pT != ultimoPctNotificado;
        boolean passouTempoMinimo = (agora - ultimoNotifyMs) >= 400;

        if (notificationBuilder != null && notificationManager != null && percentualMudou && passouTempoMinimo) {
            ultimoNotifyMs = agora;
            ultimoPctNotificado = pT;
            notificationBuilder.setProgress(100, pT, false)
                    .setContentText(getString(R.string.notif_total_fmt, pT, arquivosEnviados, totalArquivos));
            notificationManager.notify(NOTIF_ID, notificationBuilder.build());
        }
    }

    private void iniciarNotificacao(String nomeJogo, String titleId) {
        ultimoNotifyMs = 0;
        ultimoPctNotificado = -1;
        notificationBuilder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentTitle(getString(R.string.notif_enviando_fmt, nomeJogo))
                .setContentText(getString(R.string.notif_calculando_tempo))
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(true)
                .setOnlyAlertOnce(true);
        notificationManager.notify(NOTIF_ID, notificationBuilder.build());
    }

    private void finalizarNotificacao(String nomeJogo, boolean sucesso) {
        if (notificationBuilder != null && notificationManager != null) {
            if (sucesso) {
                notificationBuilder.setContentTitle(getString(R.string.notif_transferencia_concluida_title))
                        .setContentText(getString(R.string.notif_ja_esta_no_xbox_fmt, nomeJogo))
                        .setSmallIcon(android.R.drawable.stat_sys_upload_done)
                        .setProgress(0, 0, false)
                        .setOngoing(false);
            } else {
                notificationBuilder.setContentTitle(getString(R.string.notif_erro_title))
                        .setContentText(getString(R.string.notif_falha_enviar_fmt, nomeJogo))
                        .setSmallIcon(android.R.drawable.stat_sys_warning)
                        .setProgress(0, 0, false)
                        .setOngoing(false);
            }
            notificationManager.notify(NOTIF_ID, notificationBuilder.build());
        }
    }

    private void finalizarNotificacaoCancelada(String nomeJogo) {
        if (notificationBuilder != null && notificationManager != null) {
            notificationBuilder.setContentTitle(getString(R.string.notif_transferencia_cancelada_title))
                    .setContentText(nomeJogo)
                    .setSmallIcon(android.R.drawable.stat_sys_warning)
                    .setProgress(0, 0, false)
                    .setOngoing(false);
            notificationManager.notify(NOTIF_ID, notificationBuilder.build());
        }
    }
}
