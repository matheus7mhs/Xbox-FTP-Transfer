package mhs.ftp.meuxbox1;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

public class MeusJogosFragment extends Fragment {

    private RecyclerView recyclerGames;
    private GameAdapter adapter;
    private List<ListarGames> gamesList;
    private Button btnScan;
    private TextView tvStatus;

    private int totalEncontrado = 0;

    /**
     * Só executa o Runnable na UI thread se o Fragment ainda estiver anexado à Activity.
     * Sem isso, a Thread de escaneamento (que roda em segundo plano e pode demorar bastante)
     * derruba o app com NullPointerException quando o usuário sai da tela "Meus Jogos"
     * antes do escaneamento terminar (getActivity() vira null nesse meio tempo).
     */
    /**
     * Calcula quantas colunas cabem na largura disponível, usando a largura de item alvo
     * definida em dimens.xml (que também varia por tipo de tela via values-sw600dp/sw840dp).
     * Nunca retorna menos que 2 colunas.
     */
    private int calculateSpanCount(int widthPx) {
        if (getContext() == null) return 2;
        float density = getResources().getDisplayMetrics().density;
        float itemTargetWidthDp = getResources().getDimension(R.dimen.grid_item_target_width) / density;
        int spanCount = Math.round((widthPx / density) / itemTargetWidthDp);
        return Math.max(2, spanCount);
    }

    private void runOnUi(Runnable r) {
        androidx.fragment.app.FragmentActivity act = getActivity();
        if (act == null || !isAdded()) return;
        act.runOnUiThread(() -> {
            if (isAdded() && getActivity() != null) {
                r.run();
            }
        });
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_meus_jogos, container, false);

        recyclerGames = view.findViewById(R.id.recycler_games);
        btnScan = view.findViewById(R.id.btn_scan_games);
        tvStatus = view.findViewById(R.id.tv_scan_status);

        // Número de colunas fixo em 2 apenas como valor inicial; é recalculado logo abaixo
        // assim que o RecyclerView tiver sua largura real medida (celular, tablet ou desktop).
        final GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 2);
        recyclerGames.setLayoutManager(gridLayoutManager);
        gamesList = new ArrayList<>();
        adapter = new GameAdapter(getContext(), gamesList);
        recyclerGames.setAdapter(adapter);

        // Ajusta o número de colunas de acordo com a largura disponível da tela (responsivo:
        // celular = menos colunas, tablet/desktop Android = mais colunas), e reajusta também
        // se a largura mudar depois (rotação de tela, modo split-screen, janela redimensionada).
        recyclerGames.addOnLayoutChangeListener((v, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom) -> {
            int width = right - left;
            if (width <= 0) return;
            int spanCount = calculateSpanCount(width);
            if (gridLayoutManager.getSpanCount() != spanCount) {
                gridLayoutManager.setSpanCount(spanCount);
            }
        });

        // Mantém o botão funcionando para caso o usuário queira atualizar manualmente
        btnScan.setOnClickListener(v -> escanearXbox());

        // Carrega instantaneamente o resultado do último escaneamento salvo em disco (cache),
        // em vez de escanear via FTP toda vez que a aba é aberta. Só escaneia de verdade se
        // não houver cache ainda (primeira vez) ou se o usuário tocar em "Escanear" manualmente.
        if (!carregarDoCache()) {
            escanearXbox();
        }

        return view;
    }

    /** Tenta carregar a lista de jogos do cache local. Retorna true se conseguiu mostrar algo. */
    private boolean carregarDoCache() {
        if (getActivity() == null) return false;
        SharedPreferences prefs = getActivity().getSharedPreferences("XboxPrefs", Context.MODE_PRIVATE);
        String ip = prefs.getString("last_ip", "");
        if (ip.isEmpty()) return false;

        GameCache.CacheResult cache = GameCache.carregar(getContext(), ip);
        if (cache == null || cache.jogos.isEmpty()) return false;

        gamesList.clear();
        gamesList.addAll(cache.jogos);
        adapter.notifyDataSetChanged();
        totalEncontrado = gamesList.size();
        tvStatus.setText(getString(R.string.status_cache_carregado_fmt, totalEncontrado));
        return true;
    }

    /**
     * Lê a porta FTP configurada nas preferências (padrão: 21), a mesma usada pela tela
     * principal para testar a conexão e enviar jogos. Se o valor salvo estiver vazio ou
     * não for um número de porta válido (1-65535), cai no padrão.
     */
    private static int obterPortaFtp(Context context) {
        if (context == null) return 21;
        SharedPreferences prefs = context.getSharedPreferences("XboxPrefs", Context.MODE_PRIVATE);
        String portaStr = prefs.getString("ftp_port", "21");
        try {
            int porta = Integer.parseInt(portaStr.trim());
            return (porta > 0 && porta <= 65535) ? porta : 21;
        } catch (Exception e) {
            return 21;
        }
    }

    /**
     * Lê o usuário/senha FTP configurados nas preferências (padrão: "xbox"/"xbox"), os
     * mesmos usados pela tela principal para testar a conexão e enviar jogos. Assim, se o
     * Xbox tiver um login FTP customizado, o escaneamento/desinstalação também funciona.
     */
    private static String obterUsuarioFtp(Context context) {
        if (context == null) return "xbox";
        SharedPreferences prefs = context.getSharedPreferences("XboxPrefs", Context.MODE_PRIVATE);
        return prefs.getString("ftp_user", "xbox");
    }

    private static String obterSenhaFtp(Context context) {
        if (context == null) return "xbox";
        SharedPreferences prefs = context.getSharedPreferences("XboxPrefs", Context.MODE_PRIVATE);
        return prefs.getString("ftp_pass", "xbox");
    }

    private void escanearXbox() {
        SharedPreferences prefs = getActivity().getSharedPreferences("XboxPrefs", Context.MODE_PRIVATE);
        String ip = prefs.getString("last_ip", "");
        int porta = obterPortaFtp(getActivity());
        String usuario = obterUsuarioFtp(getActivity());
        String senha = obterSenhaFtp(getActivity());

        if (ip.isEmpty()) {
            Toast.makeText(getContext(), R.string.toast_configure_ip_primeiro, Toast.LENGTH_SHORT).show();
            return;
        }

        tvStatus.setText(R.string.status_limpando_cache);
        btnScan.setEnabled(false);
        gamesList.clear();
        adapter.notifyDataSetChanged();
        totalEncontrado = 0;

        new Thread(() -> {
            FTPClient ftp = new FTPClient();
            try {
                ftp.setConnectTimeout(5000);
                ftp.connect(ip, porta);
                ftp.login(usuario, senha);
                ftp.enterLocalPassiveMode();
                ftp.setFileType(FTPClient.BINARY_FILE_TYPE);

                // ==========================================
                // 1. ESCANEANDO JOGOS FORMATO GOD
                // ==========================================
                String[] caminhosGod = {
                        "/Hdd1/Content/0000000000000000",
                        "/Usb0/Content/0000000000000000",
                        "/Usb1/Content/0000000000000000",
                        "/Usb2/Content/0000000000000000"
                };

                for (String path : caminhosGod) {
                    runOnUi(() -> tvStatus.setText(getString(R.string.status_varrendo_god_fmt, path)));
                    
                    if (!ftp.changeWorkingDirectory(path)) continue;

                    FTPFile[] titleIdFolders = ftp.listFiles();
                    if (titleIdFolders == null) continue;

                    for (FTPFile tidDir : titleIdFolders) {
                        String tid = tidDir.getName();
                        
                        if (tid == null || tid.length() != 8 || !tid.matches("^[0-9a-fA-F]+$") || tid.startsWith("FF")) {
                            continue;
                        }

                        if (ftp.changeWorkingDirectory(tid)) {
                            FTPFile[] subFolders = ftp.listFiles();
                            boolean eJogoValido = false;

                            if (subFolders != null) {
                                for (FTPFile sub : subFolders) {
                                    if (sub.isDirectory() && sub.getName().equals("00007000")) {
                                        if (ftp.changeWorkingDirectory("00007000")) {
                                            FTPFile[] arquivosJogo = ftp.listFiles();
                                            if (arquivosJogo != null && arquivosJogo.length > 0) {
                                                eJogoValido = true;
                                            }
                                            ftp.changeToParentDirectory(); 
                                        }
                                    }
                                }
                            }

                            ftp.changeToParentDirectory(); 

                            if (eJogoValido) {
                                String nome = GameDatabase.getNomeDoJogo(tid);
                                String fullPath = path + "/" + tid;
                                gamesList.add(new ListarGames(tid.toUpperCase(), nome, fullPath, "GOD"));
                                totalEncontrado++;
                                final int posicaoInserida = gamesList.size() - 1;
                                runOnUi(() -> adapter.notifyItemInserted(posicaoInserida));
                            }
                        }
                    }
                }

                // ==========================================
                // 2. ESCANEANDO JOGOS FORMATO XEX
                // ==========================================
                String[] raizesDeArmazenamento = { "/Hdd1", "/Usb0", "/Usb1", "/Usb2" };
                
                for (String raiz : raizesDeArmazenamento) {
                    varrerPastaXexRecursivo(ftp, raiz, 0);
                }

                // ==========================================
                // 3. ESCANEANDO JOGOS XBLA (ARCADE / STFS)
                // ==========================================
                // Estrutura REAL do XBLA instalado no Xbox 360 (confirmada na
                // documentação do console e da Aurora):
                // Content/0000000000000000/<TitleID>/000D0000/
                // onde 000D0000 é o Content Type de "Arcade Title" e lá dentro
                // fica DIRETAMENTE o arquivo do jogo (nome sem extensão,
                // formato de pacote STFS: CON / LIVE / PIRS). NÃO existe pasta
                // .data — essa estrutura é só do GOD (00007000).
                // Para catalogar, lemos os primeiros bytes do arquivo pelo FTP
                // (sem salvar nada no celular) e extraímos o TitleID do
                // cabeçalho STFS em 0x360.
                // ==========================================
                String[] caminhosXbla = {
                        "/Hdd1/Content/0000000000000000",
                        "/Usb0/Content/0000000000000000",
                        "/Usb1/Content/0000000000000000",
                        "/Usb2/Content/0000000000000000"
                };

                for (String path : caminhosXbla) {
                    runOnUi(() -> tvStatus.setText(getString(R.string.status_varrendo_xbla_fmt, path)));

                    if (!ftp.changeWorkingDirectory(path)) continue;

                    FTPFile[] titleIdFolders = ftp.listFiles();
                    if (titleIdFolders == null) continue;

                    for (FTPFile tidDir : titleIdFolders) {
                        String tid = tidDir.getName();

                        if (tid == null || tid.length() != 8 || !tid.matches("^[0-9a-fA-F]+$") || tid.startsWith("FF")) {
                            continue;
                        }

                        // Content Types que indicam jogo Arcade XBLA instalado
                        String[] tiposArcade = { "000D0000", "000D0001" };
                        boolean temXblaNesteTitleId = false;

                        for (String tipo : tiposArcade) {
                            if (temXblaNesteTitleId) break;

                            String fullTipoPath = path + "/" + tid + "/" + tipo;
                            if (!ftp.changeWorkingDirectory(fullTipoPath)) continue;

                            FTPFile[] arquivosTipo = ftp.listFiles();
                            if (arquivosTipo == null) continue;

                            // A pasta do XBLA contém o arquivo STFS do jogo
                            // diretamente (nome tipo hash, sem extensão)
                            for (FTPFile arquivo : arquivosTipo) {
                                if (!arquivo.isFile()) continue;

                                String nomeArquivo = arquivo.getName();
                                if (nomeArquivo == null || nomeArquivo.startsWith(".") || nomeArquivo.startsWith("$")) continue;

                                // Lê o cabeçalho STFS do arquivo pelo FTP
                                String[] info = extrairInfoStfsFtpArquivo(ftp, nomeArquivo);
                                if (info == null) continue;

                                String idExtraida = info[0];

                                // Evita re-listar um mesmo TitleID já catalogado
                                // (ex.: GOD do mesmo jogo em outro disco)
                                boolean jaListado = false;
                                for (ListarGames g : gamesList) {
                                    if (idExtraida != null && g.getTitleId().equals(idExtraida)) {
                                        jaListado = true;
                                        break;
                                    }
                                }
                                if (jaListado) { temXblaNesteTitleId = true; break; }

                                String nomeJogo;
                                String idParaCapa;
                                String pathDoJogo = fullTipoPath;

                                if (idExtraida != null) {
                                    nomeJogo = GameDatabase.getNomeDoJogo(idExtraida);
                                    idParaCapa = idExtraida;
                                } else {
                                    nomeJogo = getString(R.string.game_name_xbla_padrao);
                                    idParaCapa = "XBLA_DESCONHECIDO";
                                }

                                String finalNome = nomeJogo;
                                String finalId = idParaCapa;
                                String finalPath = pathDoJogo;

                                gamesList.add(new ListarGames(finalId, finalNome, finalPath, "XBLA"));
                                totalEncontrado++;
                                final int posicaoInserida = gamesList.size() - 1;
                                runOnUi(() -> adapter.notifyItemInserted(posicaoInserida));
                                temXblaNesteTitleId = true;
                                break;
                            }
                        }
                    }
                }

                // Salva o resultado em disco para a próxima vez que a aba "Meus Jogos" for aberta.
                if (getContext() != null) {
                    GameCache.salvar(getContext(), ip, new ArrayList<>(gamesList));
                }

                final int finalTotal = totalEncontrado;
                runOnUi(() -> {
                    tvStatus.setText(getString(R.string.status_finalizado_jogos_fmt, finalTotal));
                    btnScan.setEnabled(true);
                });

            } catch (Exception e) {
                runOnUi(() -> {
                    tvStatus.setText(getString(R.string.status_erro_conexao_fmt, e.getMessage()));
                    btnScan.setEnabled(true);
                });
            } finally {
                // Antes o disconnect() só rodava no caminho de sucesso: se a Xbox caísse no meio
                // da varredura (comum, dado o resto do app existir justamente pra lidar com wifi
                // instável), a conexão FTP ficava aberta pra sempre. Cada tentativa de escanear
                // que falhasse vazava mais uma conexão, até esgotar sockets disponíveis.
                try { ftp.disconnect(); } catch (Exception ignored) {}
            }
        }).start();
    }

    /**
     * Lê o cabeçalho STFS de um arquivo individual (pacote do jogo XBLA)
     * pelo FTP, sem salvar nada no celular. Retorna [TitleID] ou null.
     * O pacote STFS tem magic "CON ", "LIVE" ou "PIRS" no início e TitleID
     * em 0x360 (big-endian).
     */
    private String[] extrairInfoStfsFtpArquivo(FTPClient ftp, String nomeArquivo) {
        try {
            InputStream is = ftp.retrieveFileStream(nomeArquivo);
            if (is == null) return null;

            byte[] header = new byte[0x364];
            int lido;
            try {
                lido = lerExatamente(is, header);
            } finally {
                // Antes, se lerExatamente() lançasse exceção no meio da leitura (rede instável),
                // is.close() e completePendingCommand() nunca rodavam: o stream vazava E a conexão
                // FTP ficava "dessincronizada" (esperando a confirmação do comando), contaminando
                // silenciosamente os comandos seguintes na mesma varredura.
                try { is.close(); } catch (Exception ignored2) {}
                try { ftp.completePendingCommand(); } catch (Exception ignored2) {}
            }

            if (lido >= 0x364) {
                String magic = new String(header, 0, 4);
                if (magic.equals("CON ") || magic.equals("PIRS") || magic.equals("LIVE")) {
                    String titleId = bytesParaHex(header, 0x360, 0x364);
                    return new String[]{ titleId };
                }
            }
        } catch (Exception ignored) {}
        return null;
    }

    private String bytesParaHex(byte[] buffer, int inicio, int fim) {
        StringBuilder sb = new StringBuilder();
        for (int i = inicio; i < fim; i++) {
            sb.append(String.format("%02X", buffer[i]));
        }
        return sb.toString();
    }

    private void varrerPastaXexRecursivo(FTPClient ftp, String currentPath, int depth) throws Exception {
        if (depth > 2) return; 

        runOnUi(() -> tvStatus.setText(getString(R.string.status_lendo_fmt, currentPath)));

        if (!ftp.changeWorkingDirectory(currentPath)) return;

        FTPFile[] files = ftp.listFiles();
        if (files == null) return;

        boolean temDefaultXex = false;
        String idMarcador = null;

        for (FTPFile file : files) {
            if (file.isFile()) {
                String nome = file.getName().toLowerCase();
                
                if (nome.equals("default.xex")) {
                    temDefaultXex = true;
                } else if (nome.startsWith("mhs_id_") && nome.endsWith(".txt")) {
                    idMarcador = nome.substring(7, nome.length() - 4).toUpperCase();
                }
            }
        }

        if (temDefaultXex) {
            String nomeJogo;
            String idParaCapa;

            if (idMarcador != null) {
                nomeJogo = GameDatabase.getNomeDoJogo(idMarcador);
                idParaCapa = idMarcador;
            } else {
                // ==========================================
                // MODO RAIO-X: Catalogação Automática!
                // ==========================================
                runOnUi(() -> tvStatus.setText(R.string.status_catalogando));
                
                String idExtraida = null;
                try {
                    // Baixa SÓ o comecinho do arquivo, sem salvar no celular!
                    InputStream is = ftp.retrieveFileStream(currentPath + "/default.xex");
                    if (is != null) {
                        idExtraida = extrairIdDoStream(is);
                        is.close();
                        ftp.completePendingCommand(); // Corta a conexão FTP após ler o Stream
                    }
                } catch (Exception ignored) {}

                if (idExtraida != null) {
                    try {
                        String markerPath = currentPath + "/mhs_id_" + idExtraida + ".txt";
                        InputStream dummyIn = new ByteArrayInputStream("MHS".getBytes());
                        ftp.storeFile(markerPath, dummyIn);
                    } catch (Exception ignored) {}

                    nomeJogo = GameDatabase.getNomeDoJogo(idExtraida);
                    idParaCapa = idExtraida;
                } else {
                    String[] partes = currentPath.split("/");
                    nomeJogo = getString(R.string.game_name_xex_fmt, partes[partes.length - 1]);
                    idParaCapa = "XEX_DESCONHECIDO";
                }
            }

            String finalNome = nomeJogo;
            String finalId = idParaCapa;
            String finalPath = currentPath;

            gamesList.add(new ListarGames(finalId, finalNome, finalPath));
            totalEncontrado++;
            final int posicaoInserida = gamesList.size() - 1;
            runOnUi(() -> adapter.notifyItemInserted(posicaoInserida));

            return; 
        }

        for (FTPFile dir : files) {
            if (dir.isDirectory()) {
                String dirName = dir.getName();
                String dirLower = dirName.toLowerCase();

                if (depth == 0) {
                    if (dirLower.equals("content") || dirLower.equals("cache") ||
                        dirLower.equals("syscache") || dirLower.equals("aurora") ||
                        dirLower.equals("freestyle") || dirLower.equals("fsd") ||
                        dirLower.equals("fsd3") || dirLower.equals("plugins") ||
                        dirLower.equals("compatibility") || dirLower.equals("dashlaunch")) {
                        continue;
                    }
                }

                if (dirName.startsWith("$") || dirName.startsWith(".")) continue;

                varrerPastaXexRecursivo(ftp, currentPath + "/" + dirName, depth + 1);
                ftp.changeWorkingDirectory(currentPath);
            }
        }
    }

    private String extrairIdDoStream(InputStream is) {
        try {
            byte[] baseHeader = new byte[0x18];
            if (lerExatamente(is, baseHeader) < 0x18) return null;

            if (baseHeader[0] != 'X' || baseHeader[1] != 'E' || baseHeader[2] != 'X' || baseHeader[3] != '2') return null;

            ByteBuffer bbBase = ByteBuffer.wrap(baseHeader);
            bbBase.order(ByteOrder.BIG_ENDIAN);
            int numHeaders = bbBase.getInt(0x14);

            byte[] optHeaders = new byte[numHeaders * 8];
            if (lerExatamente(is, optHeaders) < optHeaders.length) return null;

            ByteBuffer optBb = ByteBuffer.wrap(optHeaders);
            optBb.order(ByteOrder.BIG_ENDIAN);

            int offsetExecutionInfo = -1;
            for (int i = 0; i < numHeaders; i++) {
                int key = optBb.getInt();
                int value = optBb.getInt();
                if (key == 0x00040006) {
                    offsetExecutionInfo = value;
                    break;
                }
            }

            if (offsetExecutionInfo != -1) {
                int bytesJaLidos = 0x18 + (numHeaders * 8);
                int bytesParaPular = offsetExecutionInfo - bytesJaLidos;
                
                if (bytesParaPular > 0) {
                    long pulado = 0;
                    while (pulado < bytesParaPular) {
                        long p = is.skip(bytesParaPular - pulado);
                        if (p == 0) { if (is.read() == -1) break; p = 1; }
                        pulado += p;
                    }
                }

                byte[] execInfo = new byte[0x10]; 
                if (lerExatamente(is, execInfo) < 0x10) return null;

                ByteBuffer execBb = ByteBuffer.wrap(execInfo);
                execBb.order(ByteOrder.BIG_ENDIAN);
                
                int titleIdInt = execBb.getInt(0x0C); 
                return String.format("%08X", titleIdInt);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Calcula o tamanho TOTAL de um jogo no Xbox pelo FTP, somando:
     * - O jogo principal (GOD, XBLA ou pasta XEX)
     * - DLCs (Content Type 00000002) quando aplicável
     * - Saves (Content Type 00000001) quando aplicável
     * - Title Updates (Content Type 000B0000) quando aplicável
     *
     * Conexão FTP nova e independente da varredura, então funciona em
     * qualquer momento (ao clicar em um jogo, por exemplo).
     */
    public static String calcularTamanhoTotal(Context context, String ip, ListarGames game) {
        long jogoBytes = 0;
        long dlcBytes = 0;
        long saveBytes = 0;
        long tuBytes = 0;
        String resumo = "";

        FTPClient ftp = new FTPClient();
        try {
            ftp.setConnectTimeout(5000);
            ftp.connect(ip, obterPortaFtp(context));
            ftp.login(obterUsuarioFtp(context), obterSenhaFtp(context));
            ftp.enterLocalPassiveMode();
            ftp.setFileType(FTPClient.BINARY_FILE_TYPE);

            String tipo = game.getTipoJogo();

            if ("GOD".equals(tipo)) {
                // GOD: /Content/0000000000000000/<TitleID>/00007000/
                String godPath = game.getCaminhoFtp() + "/00007000";
                jogoBytes = somarPastaFtp(ftp, godPath);
                dlcBytes = somarPastaFtp(ftp, game.getCaminhoFtp() + "/00000002");
                saveBytes = somarSavesContent(ftp, game.getCaminhoFtp());
                tuBytes = somarPastaFtp(ftp, game.getCaminhoFtp() + "/000B0000");
            } else if ("XBLA".equals(tipo)) {
                // XBLA: /Content/0000000000000000/<TitleID>/000D0000/
                jogoBytes = somarPastaFtp(ftp, game.getCaminhoFtp());
                String raizXbla = game.getCaminhoFtp().replace("/000D0000", "");
                dlcBytes = somarPastaFtp(ftp, raizXbla + "/00000002");
                saveBytes = somarSavesContent(ftp, raizXbla);
                tuBytes = somarPastaFtp(ftp, raizXbla + "/000B0000");
            } else {
                // XEX: soma a pasta do jogo + Content DLC/TU/Saves no TitleID correspondente
                jogoBytes = somarPastaFtp(ftp, game.getCaminhoFtp());
                String tid = game.getTitleId();
                // Procura a pasta do TitleID em Hdd1/UsbX/Content/
                String[] raizes = { "/Hdd1", "/Usb0", "/Usb1", "/Usb2" };
                for (String raiz : raizes) {
                    String content = raiz + "/Content";
                    if (!ftp.changeWorkingDirectory(content)) continue;
                    FTPFile[] dirs = ftp.listFiles();
                    if (dirs == null) continue;
                    for (FTPFile d : dirs) {
                        if (d == null || !d.isDirectory()) continue;
                        String nome = d.getName();
                        if (nome.equals("0000000000000000") || nome.length() == 16) {
                            String base = content + "/" + nome + "/" + tid;
                            if (dlcBytes == 0) dlcBytes = somarPastaFtp(ftp, base + "/00000002");
                            if (saveBytes == 0) saveBytes = somarSavesContent(ftp, content, tid);
                            if (tuBytes == 0) tuBytes = somarPastaFtp(ftp, base + "/000B0000");
                        }
                    }
                    break;
                }
            }

            // Monta o resumo (mostra apenas as partes relevantes)
            StringBuilder sb = new StringBuilder();
            if (dlcBytes > 0) sb.append(context.getString(R.string.resumo_dlc_fmt, formatarBytes(dlcBytes))).append("  ");
            if (saveBytes > 0) sb.append(context.getString(R.string.resumo_save_fmt, formatarBytes(saveBytes))).append("  ");
            if (tuBytes > 0) sb.append(context.getString(R.string.resumo_tu_fmt, formatarBytes(tuBytes)));
            resumo = sb.toString().trim();

        } catch (Exception ignored) {
        } finally {
            try { ftp.disconnect(); } catch (Exception ignored) {}
        }

        long totalBytes = jogoBytes + dlcBytes + saveBytes + tuBytes;
        String total = totalBytes > 0
                ? formatarBytes(totalBytes)
                : context.getString(R.string.tamanho_indisponivel);

        if (!resumo.isEmpty()) {
            return total + "\n" + resumo;
        }
        return total;
    }

    /** Soma os saves (00000001) do TitleID na pasta informada (público + pastas de perfil de 16 chars). */
    private static long somarSavesContent(FTPClient ftp, String raizTitleId) {
        long total = somarPastaFtp(ftp, raizTitleId + "/00000001");
        try {
            String pai = raizTitleId.substring(0, raizTitleId.lastIndexOf('/'));
            String tid = raizTitleId.substring(raizTitleId.lastIndexOf('/') + 1);
            if (ftp.changeWorkingDirectory(pai)) {
                FTPFile[] dirs = ftp.listFiles();
                if (dirs != null) {
                    for (FTPFile d : dirs) {
                        if (d == null || !d.isDirectory()) continue;
                        String nome = d.getName();
                        if (nome.length() == 16 && !nome.equals("0000000000000000")) {
                            total += somarPastaFtp(ftp, pai + "/" + nome + "/" + tid + "/00000001");
                        }
                    }
                }
                ftp.changeWorkingDirectory(raizTitleId);
            }
        } catch (Exception ignored) {}
        return total;
    }

    /** Soma os saves (00000001) de um TitleID dentro das pastas raiz informadas. */
    private static long somarSavesContent(FTPClient ftp, String contentDir, String tid) {
        long total = 0;
        try {
            total += somarPastaFtp(ftp, contentDir + "/0000000000000000/" + tid + "/00000001");
            if (!ftp.changeWorkingDirectory(contentDir)) return total;
            FTPFile[] dirs = ftp.listFiles();
            if (dirs == null) return total;
            for (FTPFile d : dirs) {
                if (d == null || !d.isDirectory()) continue;
                String nome = d.getName();
                if (nome.length() == 16 && !nome.equals("0000000000000000")) {
                    total += somarPastaFtp(ftp, contentDir + "/" + nome + "/" + tid + "/00000001");
                }
            }
            // Volta para o diretório de origem
            ftp.changeToParentDirectory();
        } catch (Exception ignored) {}
        return total;
    }

    /** Soma recursivamente o tamanho de todos os arquivos de uma pasta pelo FTP. */
    private static long somarPastaFtp(FTPClient ftp, String path) {
        long total = 0;
        try {
            if (!ftp.changeWorkingDirectory(path)) return 0;
            FTPFile[] files = ftp.listFiles();
            if (files == null) return 0;
            for (FTPFile f : files) {
                if (f.isFile()) {
                    total += f.getSize();
                } else if (f.isDirectory()) {
                    String name = f.getName();
                    if (name.startsWith("$") || name.startsWith(".")) continue;
                    total += somarPastaFtp(ftp, path + "/" + name);
                    ftp.changeWorkingDirectory(path); // Restaura a posição após descer
                }
            }
        } catch (Exception ignored) {}
        return total;
    }

    /**
     * Lista todo o conteúdo extra (DLCs, saves e Title Updates) de um jogo
     * pelo FTP. Retorna uma lista de textos no formato "secao | nome | tamanho".
     */
    public static List<String> listarConteudoExtra(Context context, String ip, ListarGames game) {
        List<String> linhas = new ArrayList<>();
        FTPClient ftp = new FTPClient();
        try {
            ftp.setConnectTimeout(5000);
            ftp.connect(ip, obterPortaFtp(context));
            ftp.login(obterUsuarioFtp(context), obterSenhaFtp(context));
            ftp.enterLocalPassiveMode();
            ftp.setFileType(FTPClient.BINARY_FILE_TYPE);

            String tipo = game.getTipoJogo();
            String raizTitleId;
            String pastaJogo;

            if ("GOD".equals(tipo)) {
                raizTitleId = game.getCaminhoFtp();                       // .../TitleID/
                pastaJogo = raizTitleId + "/00007000";
            } else if ("XBLA".equals(tipo)) {
                raizTitleId = game.getCaminhoFtp().replace("/000D0000", ""); // .../TitleID/
                pastaJogo = game.getCaminhoFtp();
            } else {
                raizTitleId = null; // XEX: localiza abaixo
                pastaJogo = game.getCaminhoFtp();
            }

            // Content Types oficiais do Xbox 360:
            // 00000002 = Marketplace Content (DLC) | 00000001 = Saved Game | 000B0000 = Title Update
            coletarLinhasContent(ftp, raizTitleId, pastaJogo, "00000002", context.getString(R.string.secao_dlc), linhas);
            coletarLinhasSave(ftp, raizTitleId, pastaJogo, context.getString(R.string.secao_save), linhas);
            coletarLinhasContent(ftp, raizTitleId, pastaJogo, "000B0000", context.getString(R.string.secao_tu), linhas);
        } catch (Exception ignored) {
        } finally {
            try { ftp.disconnect(); } catch (Exception ignored) {}
        }
        return linhas;
    }

    /**
     * Lista os SAVES (Content Type 00000001) do jogo. Saves ficam na pasta do
     * perfil do usuário: Content/<ID_perfil>/<TitleID>/00000001/
     * (um pacote CON por perfil). Também procura no diretório público.
     */
    private static void coletarLinhasSave(FTPClient ftp, String raizTitleId, String pastaJogo, String secao, List<String> linhas) {
        List<String> itens = new ArrayList<>();

        if (raizTitleId != null) {
            // GOD/XBLA: raizTitleId = .../Content/0000000000000000/<TitleID> ou similar
            itens.addAll(listarItensFtp(ftp, raizTitleId + "/00000001"));

            // Saves também ficam em pastas de perfil: Content/<ID_perfil>/<TitleID>/00000001/
            // O ID do perfil tem 16 caracteres (ex.: E00015BF00008BD2); lista o pai da raizTitleId
            try {
                String pai = raizTitleId.substring(0, raizTitleId.lastIndexOf('/'));
                if (ftp.changeWorkingDirectory(pai)) {
                    FTPFile[] dirs = ftp.listFiles();
                    if (dirs != null) {
                        for (FTPFile d : dirs) {
                            if (d == null || !d.isDirectory()) continue;
                            String nome = d.getName();
                            if (nome.length() == 16 && !nome.equals("0000000000000000")) {
                                itens.addAll(listarItensFtp(ftp, pai + "/" + nome + "/" + raizTitleId.substring(raizTitleId.lastIndexOf('/') + 1) + "/00000001"));
                            }
                        }
                    }
                    ftp.changeWorkingDirectory(raizTitleId); // restaura posição
                }
            } catch (Exception ignored) {}
        } else {
            // XEX: localiza a pasta do TitleID e seus saves (público + perfis)
            String tid = pastaJogo.split("/")[pastaJogo.split("/").length - 1];
            String[] raizes = { "/Hdd1", "/Usb0", "/Usb1", "/Usb2" };
            for (String raiz : raizes) {
                String content = raiz + "/Content";
                try {
                    if (!ftp.changeWorkingDirectory(content)) continue;
                    FTPFile[] dirs = ftp.listFiles();
                    if (dirs == null) break;
                    for (FTPFile d : dirs) {
                        if (d == null || !d.isDirectory()) continue;
                        String nome = d.getName();
                        if (nome.equals("0000000000000000")) {
                            itens.addAll(listarItensFtp(ftp, content + "/0000000000000000/" + tid + "/00000001"));
                        } else if (nome.length() == 16) {
                            itens.addAll(listarItensFtp(ftp, content + "/" + nome + "/" + tid + "/00000001"));
                        }
                    }
                    break; // já varreu as pastas de perfil dessa raiz
                } catch (Exception ignored) {}
            }
        }

        if (!itens.isEmpty()) {
            linhas.add(secao);
            linhas.addAll(itens);
        }
    }

    /**
     * Percorre uma pasta de Content Type (ex.: 00000002) e adiciona uma linha
     * por sub-item encontrado. Funciona para GOD/XBLA (raizTitleId informado)
     * e para XEX (busca a pasta do TitleID em Hdd1/UsbX/Content/0000000000000000/).
     */
    private static void coletarLinhasContent(FTPClient ftp, String raizTitleId, String pastaJogo, String contentType, String secao, List<String> linhas) {
        String alvo = null;
        if (raizTitleId != null) {
            alvo = raizTitleId + "/" + contentType;
        } else {
            // XEX: procura a pasta do TitleID em Content
            String[] raizes = { "/Hdd1", "/Usb0", "/Usb1", "/Usb2" };
            for (String raiz : raizes) {
                String base = raiz + "/Content/0000000000000000/" + pastaJogo.split("/")[pastaJogo.split("/").length - 1];
                try {
                    if (ftp.changeWorkingDirectory(base)) {
                        alvo = base + "/" + contentType;
                        break;
                    }
                } catch (Exception ignored) {}
            }
        }
        if (alvo == null) return;

        List<String> itens = listarItensFtp(ftp, alvo);
        if (itens.isEmpty()) return;
        linhas.add(secao);
        linhas.addAll(itens);
    }

    /** Preenche com espaços para alinhar os tamanhos na margem direita (largura útil ~26 caracteres). */
    private static String padParaTamanho(String nome) {
        int espacos = Math.max(2, 26 - nome.length());
        StringBuilder sb = new StringBuilder(espacos);
        for (int i = 0; i < espacos; i++) sb.append(' ');
        return sb.toString();
    }

    /** Lista sub-itens de uma pasta com nome e tamanho formatado. */
    private static List<String> listarItensFtp(FTPClient ftp, String path) {
        List<String> itens = new ArrayList<>();
        try {
            if (!ftp.changeWorkingDirectory(path)) return itens;
            FTPFile[] files = ftp.listFiles();
            if (files == null) return itens;
            for (FTPFile f : files) {
                if (f == null || f.getName() == null) continue;
                if (f.getName().startsWith("$") || f.getName().startsWith(".")) continue;
                itens.add("  " + f.getName() + padParaTamanho(f.getName()) + " " + formatarBytes(f.getSize()));
            }
        } catch (Exception ignored) {}
        return itens;
    }

    /**
     * Desinstala um jogo do Xbox pelo FTP.
     * @param jogoApenas true = remove só a pasta do jogo; false = remove jogo + DLC + saves + TU
     * @param callback  recebe true/false ao final
     */
    public static void desinstalarJogo(Context context, String ip, ListarGames game, boolean jogoApenas, Runnable callback) {
        int porta = obterPortaFtp(context);
        String usuario = obterUsuarioFtp(context);
        String senha = obterSenhaFtp(context);
        executorDesinstalar.execute(() -> {
            boolean sucesso = false;
            FTPClient ftp = new FTPClient();
            try {
                ftp.setConnectTimeout(5000);
                ftp.connect(ip, porta);
                ftp.login(usuario, senha);
                ftp.enterLocalPassiveMode();
                ftp.setFileType(FTPClient.BINARY_FILE_TYPE);

                List<String> pastasParaApagar = new ArrayList<>();

                if ("GOD".equals(game.getTipoJogo())) {
                    pastasParaApagar.add(game.getCaminhoFtp() + "/00007000");
                    if (!jogoApenas) {
                        pastasParaApagar.add(game.getCaminhoFtp() + "/00000002");
                        pastasParaApagar.add(game.getCaminhoFtp() + "/00000001");
                        pastasParaApagar.add(game.getCaminhoFtp() + "/000B0000");
                    }
                } else if ("XBLA".equals(game.getTipoJogo())) {
                    pastasParaApagar.add(game.getCaminhoFtp()); // 000D0000 com o pacote do jogo
                    if (!jogoApenas) {
                        String raiz = game.getCaminhoFtp().replace("/000D0000", "");
                        pastasParaApagar.add(raiz + "/00000002");
                        pastasParaApagar.add(raiz + "/00000001");
                        pastasParaApagar.add(raiz + "/000B0000");
                    }
                } else {
                    pastasParaApagar.add(game.getCaminhoFtp()); // pasta XEX
                    if (!jogoApenas) {
                        String[] raizes = { "/Hdd1", "/Usb0", "/Usb1", "/Usb2" };
                        for (String raiz : raizes) {
                            String base = raiz + "/Content/0000000000000000/" + game.getTitleId();
                            if (ftp.changeWorkingDirectory(base)) {
                                pastasParaApagar.add(base + "/00000002");
                                pastasParaApagar.add(base + "/00000001");
                                pastasParaApagar.add(base + "/000B0000");
                                break;
                            }
                        }
                    }
                }

                for (String pasta : pastasParaApagar) {
                    apagarPastaRecursivo(ftp, pasta);
                }
                sucesso = true;
            } catch (Exception ignored) {
            } finally {
                try { ftp.disconnect(); } catch (Exception ignored) {}
                final boolean ok = sucesso;
                if (callback != null) mainCallback.post(callback);
                lastDeleteOk = ok;
            }
        });
    }

    private static final android.os.Handler mainCallback = new android.os.Handler(android.os.Looper.getMainLooper());
    private static volatile boolean lastDeleteOk = false;

    /** Último resultado da desinstalação (true = sucesso). */
    public static boolean deleteConcluido() { return lastDeleteOk; }
    private static final java.util.concurrent.ExecutorService executorDesinstalar = java.util.concurrent.Executors.newSingleThreadExecutor();

    /** Remove recursivamente uma pasta do FTP (apaga arquivos e depois os subdiretórios). */
    private static void apagarPastaRecursivo(FTPClient ftp, String path) {
        try {
            if (!ftp.changeWorkingDirectory(path)) return;
            FTPFile[] files = ftp.listFiles();
            if (files == null) return;
            for (FTPFile f : files) {
                if (f == null || f.getName() == null) continue;
                if (f.getName().startsWith("$") || f.getName().startsWith(".")) continue;
                if (f.isFile()) {
                    ftp.deleteFile(f.getName());
                } else if (f.isDirectory()) {
                    apagarPastaRecursivo(ftp, path + "/" + f.getName());
                    ftp.changeWorkingDirectory(path); // restaura posição antes de remover
                }
            }
            // Volta um nível para poder remover a própria pasta vazia
            ftp.changeToParentDirectory();
            String pastaNome = path.substring(path.lastIndexOf('/') + 1);
            ftp.removeDirectory(path);
        } catch (Exception ignored) {}
    }

    /** Formata bytes em KB/MB/GB conforme a magnitude. */
    public static String formatarBytes(long bytes) {
        if (bytes <= 0) return "0 B";
        if (bytes < 1024) return bytes + " B";
        double mb = bytes / (1024.0 * 1024);
        if (mb < 1024) return String.format("%.1f MB", mb);
        return String.format("%.2f GB", mb / 1024.0);
    }

    private int lerExatamente(InputStream is, byte[] buffer) throws IOException {
        int lido = 0;
        while (lido < buffer.length) {
            int r = is.read(buffer, lido, buffer.length - lido);
            if (r == -1) break;
            lido += r;
        }
        return lido;
    }
}
