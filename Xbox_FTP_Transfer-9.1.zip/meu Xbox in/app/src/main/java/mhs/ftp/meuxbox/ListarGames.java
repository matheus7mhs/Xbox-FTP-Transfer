package mhs.ftp.meuxbox1;

public class ListarGames {
    private String titleId;
    private String nome;
    private String coverUrl;
    private String caminhoFtp;
    private String tipoJogo; // GOD, XEX ou XBLA (catalogação)

    public ListarGames(String titleId, String nome, String caminhoFtp) {
        this.titleId = titleId;
        this.nome = nome;
        this.caminhoFtp = caminhoFtp;
        // Gera a URL da capa automaticamente baseada no TitleID
        this.coverUrl = "http://xboxunity.net/Resources/Lib/Icon.php?tid=" + titleId;
        // Tipo padrão XEX; GOD e XBLA sobrescrevem durante a varredura
        this.tipoJogo = "XEX";
    }

    public ListarGames(String titleId, String nome, String caminhoFtp, String tipoJogo) {
        this.titleId = titleId;
        this.nome = nome;
        this.caminhoFtp = caminhoFtp;
        this.coverUrl = "http://xboxunity.net/Resources/Lib/Icon.php?tid=" + titleId;
        this.tipoJogo = tipoJogo != null ? tipoJogo.toUpperCase() : "XEX";
    }

    public String getTitleId() { return titleId; }
    public String getNome() { return nome; }
    public String getCoverUrl() { return coverUrl; }
    public String getCaminhoFtp() { return caminhoFtp; }
    public String getTipoJogo() { return tipoJogo; }
}
