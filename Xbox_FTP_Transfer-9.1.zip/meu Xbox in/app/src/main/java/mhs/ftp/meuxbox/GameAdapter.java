package mhs.ftp.meuxbox1;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.Toast;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class GameAdapter extends RecyclerView.Adapter<GameAdapter.GameViewHolder> {

    private Context context;
    private List<ListarGames> gamesList;

    // Compartilhados entre todas as instâncias do adapter (evita criar um pool de threads novo
    // toda vez que a tela "Meus Jogos" é reaberta, e mantém as imagens já decodificadas em memória
    // entre uma rolagem e outra da lista, sem precisar reler do disco toda hora).
    private static final ExecutorService executor = Executors.newFixedThreadPool(4);
    private static final LruCache<String, Bitmap> memoryCache;
    static {
        int maxKb = (int) (Runtime.getRuntime().maxMemory() / 1024 / 8); // 1/8 da memória disponível
        memoryCache = new LruCache<String, Bitmap>(maxKb) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                return bitmap.getByteCount() / 1024;
            }
        };
    }

    private Handler mainHandler = new Handler(Looper.getMainLooper());

    public GameAdapter(Context context, List<ListarGames> gamesList) {
        this.context = context;
        this.gamesList = gamesList;
    }

    @NonNull
    @Override
    public GameViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_game, parent, false);
        return new GameViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GameViewHolder holder, int position) {
        ListarGames game = gamesList.get(position);
        
        holder.tvName.setText(game.getNome());
        holder.tvTitleId.setText(game.getTitleId());
        holder.tvTipoJogo.setText(game.getTipoJogo());
        
        holder.imgCover.setTag(game.getTitleId());
        // Limpa a imagem anterior para não bugar ao rolar a lista rápido
        holder.imgCover.setImageBitmap(null); 

        // Download do ícone quadrado (XboxUnity) - Passando o ProgressBar da lista
        carregarImagemComCache(game.getTitleId(), game.getCoverUrl(), holder.imgCover, holder.progressLoad);

        holder.itemView.setOnClickListener(v -> abrirDialogoDetalhes(game));
    }

    @Override
    public int getItemCount() {
        return gamesList.size();
    }

    /**
     * Calcula a largura ideal para diálogos: 90% da tela no celular, mas nunca maior que
     * dialog_max_width (definido em dimens.xml e maior em values-sw600dp/sw840dp). Isso evita
     * diálogos gigantes e esticados em tablets e telas "desktop" Android.
     */
    private int calcularLarguraDialogo() {
        int largura90 = (int) (context.getResources().getDisplayMetrics().widthPixels * 0.90);
        int larguraMaxima = context.getResources().getDimensionPixelSize(R.dimen.dialog_max_width);
        return Math.min(largura90, larguraMaxima);
    }

    private void abrirDialogoDetalhes(ListarGames game) {
        Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_detalhes);
        
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        
        // Ajusta a largura do diálogo de forma responsiva (celular/tablet/desktop)
        int width = calcularLarguraDialogo();
        dialog.getWindow().setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT);

        ImageView imgCover = dialog.findViewById(R.id.dialog_cover);
        ProgressBar progDialog = dialog.findViewById(R.id.dialog_progress);
        TextView tvName = dialog.findViewById(R.id.dialog_name);
        TextView tvTid = dialog.findViewById(R.id.dialog_tid);
        TextView tvPath = dialog.findViewById(R.id.dialog_path);
        TextView tvTipo = dialog.findViewById(R.id.dialog_tipo);
        Button btnClose = dialog.findViewById(R.id.btn_close_dialog);

        tvName.setText(game.getNome());
        tvTid.setText(context.getString(R.string.label_title_id_fmt, game.getTitleId()));
        tvPath.setText(game.getCaminhoFtp());
        tvTipo.setText(game.getTipoJogo());

        // ---- Cálculo do tamanho total (jogo + DLC + saves + Title Updates) ----
        TextView tvTamanho = dialog.findViewById(R.id.dialog_tamanho);
        TextView tvTamanhoDetalhe = dialog.findViewById(R.id.dialog_tamanho_detalhe);
        ProgressBar progTamanho = dialog.findViewById(R.id.dialog_progress_tamanho);
        tvTamanho.setText("\u2026");
        tvTamanhoDetalhe.setVisibility(View.GONE);
        progTamanho.setVisibility(View.VISIBLE);

        executor.execute(() -> {
            SharedPreferences prefs = context.getSharedPreferences("XboxPrefs", Context.MODE_PRIVATE);
            String ip = prefs.getString("last_ip", "");
            final String resultado = ip.isEmpty()
                    ? context.getString(R.string.tamanho_indisponivel)
                    : MeusJogosFragment.calcularTamanhoTotal(context, ip, game);

            mainHandler.post(() -> {
                progTamanho.setVisibility(View.GONE);
                String[] linhas = resultado.split("\n", 2);
                tvTamanho.setText(linhas[0]);
                if (linhas.length > 1) {
                    tvTamanhoDetalhe.setVisibility(View.VISIBLE);
                    tvTamanhoDetalhe.setText(linhas[1]);
                }
            });
        });

        // LINK DE NÍVEL 2: Pasta do TitleID no Archive.org
        String urlPastaId = "https://archive.org/download/xboxunity-covers-fulldump_202311/xboxunity-covers-fulldump/" + game.getTitleId() + "/";
        
        imgCover.setTag(game.getTitleId() + "_cover"); 
        // Chama o cache passando o ProgressBar da janela de detalhes
        carregarImagemComCache(game.getTitleId() + "_cover", urlPastaId, imgCover, progDialog);

        btnClose.setOnClickListener(v -> dialog.dismiss());

        // ---- Botão: Listar DLCs / Saves / TU ----
        Button btnListar = dialog.findViewById(R.id.btn_listar_conteudo);
        btnListar.setOnClickListener(v -> abrirDialogoListaConteudo(game));

        // ---- Botão: Desinstalar ----
        Button btnDesinstalar = dialog.findViewById(R.id.btn_desinstalar);
        btnDesinstalar.setOnClickListener(v -> abrirDialogoDesinstalar(game, dialog));

        dialog.show();
    }

    private void abrirDialogoListaConteudo(ListarGames game) {
        Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_lista_conteudo);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        int width = calcularLarguraDialogo();
        dialog.getWindow().setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT);

        TextView tvNome = dialog.findViewById(R.id.tv_conteudo_nome);
        TextView tvLista = dialog.findViewById(R.id.tv_conteudo_lista);
        ProgressBar progress = dialog.findViewById(R.id.progress_lista);
        Button btnFechar = dialog.findViewById(R.id.btn_fechar_lista);

        tvNome.setText(game.getNome() + " — " + game.getTitleId());
        tvLista.setText(R.string.lista_carregando);
        tvLista.setVisibility(View.GONE);
        progress.setVisibility(View.VISIBLE);

        executor.execute(() -> {
            SharedPreferences prefs = context.getSharedPreferences("XboxPrefs", Context.MODE_PRIVATE);
            String ip = prefs.getString("last_ip", "");
            final StringBuilder texto = new StringBuilder();
            final boolean vazio;
            if (ip.isEmpty()) {
                texto.append(context.getString(R.string.tamanho_indisponivel));
                vazio = true;
            } else {
                List<String> linhas = MeusJogosFragment.listarConteudoExtra(context, ip, game);
                vazio = linhas.isEmpty();
                if (!vazio) {
                    for (String linha : linhas) {
                        if (linha.startsWith("◆")) {
                            // Título de seção com sublinhado visual
                            if (texto.length() > 0) texto.append("\n");
                            texto.append(linha).append("\n");
                            texto.append("────────────────").append("\n");
                        } else {
                            texto.append(linha).append("\n");
                        }
                    }
                }
            }
            mainHandler.post(() -> {
                progress.setVisibility(View.GONE);
                tvLista.setVisibility(View.VISIBLE);
                tvLista.setText(vazio ? context.getString(R.string.sem_conteudo_extra) : texto.toString());
            });
        });

        btnFechar.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private void abrirDialogoDesinstalar(ListarGames game, Dialog dialogoPai) {
        dialogoPai.dismiss();

        Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_desinstalar);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        int width = calcularLarguraDialogo();
        dialog.getWindow().setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT);

        TextView tvNome = dialog.findViewById(R.id.tv_desinstalar_nome);
        TextView tvStatus = dialog.findViewById(R.id.tv_desinstalar_status);
        ProgressBar progress = dialog.findViewById(R.id.progress_desinstalar);
        Button btnApenasJogo = dialog.findViewById(R.id.btn_apenas_jogo);
        Button btnTudo = dialog.findViewById(R.id.btn_tudo);
        Button btnCancelar = dialog.findViewById(R.id.btn_cancelar_desinstalar);

        tvNome.setText(context.getString(R.string.desinstalar_pergunta) + "\n\n" + game.getNome());
        tvStatus.setVisibility(View.GONE);

        // Habilita os botões só depois de concluir, evita clique duplo
        android.view.View.OnClickListener desinstalar = v -> {
            final boolean jogoApenas = (v == btnApenasJogo);
            btnApenasJogo.setEnabled(false);
            btnTudo.setEnabled(false);
            btnCancelar.setEnabled(false);
            progress.setVisibility(View.VISIBLE);

            executor.execute(() -> {
                SharedPreferences prefs = context.getSharedPreferences("XboxPrefs", Context.MODE_PRIVATE);
                String ip = prefs.getString("last_ip", "");
                if (ip.isEmpty()) {
                    mainHandler.post(() -> {
                        progress.setVisibility(View.GONE);
                        Toast.makeText(context, R.string.toast_configure_ip_primeiro, Toast.LENGTH_LONG).show();
                        btnApenasJogo.setEnabled(true); btnTudo.setEnabled(true); btnCancelar.setEnabled(true);
                    });
                    return;
                }
                MeusJogosFragment.desinstalarJogo(context, ip, game, jogoApenas, () -> {
                    mainHandler.post(() -> {
                        progress.setVisibility(View.GONE);
                        boolean ok = MeusJogosFragment.deleteConcluido();
                        Toast.makeText(context, ok ? R.string.desinstalar_sucesso : R.string.desinstalar_falha, Toast.LENGTH_LONG).show();
                        dialog.dismiss();

                        // Remove o jogo da lista em tela e atualiza o cache em disco, para que ele
                        // não continue aparecendo (nem volte a aparecer ao reabrir o app) depois
                        // de ter sido desinstalado do Xbox com sucesso.
                        if (ok) {
                            int posicao = gamesList.indexOf(game);
                            if (posicao != -1) {
                                gamesList.remove(posicao);
                                notifyItemRemoved(posicao);
                            }
                            if (!ip.isEmpty()) {
                                GameCache.salvar(context, ip, new java.util.ArrayList<>(gamesList));
                            }
                        }
                    });
                });
            });
        };

        btnApenasJogo.setOnClickListener(desinstalar);
        btnTudo.setOnClickListener(desinstalar);
        btnCancelar.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    // Método de cache atualizado para receber e controlar o ProgressBar
    private void carregarImagemComCache(String titleId, String urlStr, ImageView imageView, ProgressBar progressBar) {
        // 1. CACHE EM MEMÓRIA - mais rápido possível, sem tocar em disco nem em threads
        Bitmap emMemoria = memoryCache.get(titleId);
        if (emMemoria != null) {
            imageView.setImageBitmap(emMemoria);
            if (progressBar != null) progressBar.setVisibility(View.GONE);
            return;
        }

        File cacheDir = new File(context.getCacheDir(), "xbox_covers");
        if (!cacheDir.exists()) cacheDir.mkdirs();
        
        File imageFile = new File(cacheDir, titleId + ".jpg");

        // 2. CACHE EM DISCO - Se já tem a imagem, esconde o loading e mostra na hora
        if (imageFile.exists() && imageFile.length() > 500) {
            if (progressBar != null) progressBar.setVisibility(View.VISIBLE);
            executor.execute(() -> {
                Bitmap bitmap = decodificarReduzido(imageFile.getAbsolutePath(), 200, 200);
                if (bitmap != null) memoryCache.put(titleId, bitmap);
                mainHandler.post(() -> {
                    if (bitmap != null && imageView.getTag() != null && imageView.getTag().equals(titleId)) {
                        imageView.setImageBitmap(bitmap);
                    }
                    if (progressBar != null) progressBar.setVisibility(View.GONE);
                });
            });
            return;
        }

        // Se não tem no cache, ativa o loading e vai buscar na internet
        if (progressBar != null) progressBar.setVisibility(View.VISIBLE);

        executor.execute(() -> {
            HttpURLConnection connection = null;
            try {
                boolean sucesso = false;

                // LÓGICA DE RASPAGEM PARA O ARCHIVE.ORG (CAPAS GRANDES)
                if (urlStr.contains("archive.org")) {
                    connection = (HttpURLConnection) new URL(urlStr).openConnection();
                    connection.setRequestProperty("User-Agent", "Mozilla/5.0");
                    connection.setConnectTimeout(10000);

                    if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        InputStream inHtml = connection.getInputStream();
                        Scanner scanner = new Scanner(inHtml).useDelimiter("\\A");
                        String html = scanner.hasNext() ? scanner.next() : "";
                        inHtml.close();
                        connection.disconnect();

                        String variante = null;
                        String[] tags = html.split("<a href=\"");
                        for (int i = 1; i < tags.length; i++) {
                            String link = tags[i].split("\"")[0];
                            if (link.endsWith("/") && !link.equals("../")) {
                                variante = link;
                                break;
                            }
                        }

                        if (variante != null) {
                            String[] nomesImagens = {"boxart.png", "front.png", "boxarte.png"};
                            for (String nome : nomesImagens) {
                                String urlFinal = urlStr + variante + nome;
                                
                                connection = (HttpURLConnection) new URL(urlFinal).openConnection();
                                connection.setRequestProperty("User-Agent", "Mozilla/5.0");
                                connection.setInstanceFollowRedirects(true);
                                
                                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                                    // try-with-resources: garante que input/output fecham mesmo se a
                                    // conexão cair no meio do download (evita vazamento de file descriptors
                                    // em wifi instável, que ao longo de várias capas baixadas pode causar
                                    // "Too many open files" e travar o app sem explicação aparente).
                                    try (InputStream input = connection.getInputStream();
                                         FileOutputStream output = new FileOutputStream(imageFile)) {
                                        byte[] buffer = new byte[4096];
                                        int read;
                                        while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
                                    }

                                    if (imageFile.length() > 500) {
                                        sucesso = true;
                                        break; 
                                    }
                                }
                                connection.disconnect();
                            }
                        }
                    }
                } 
                // LÓGICA PADRÃO PARA ÍCONES (XBOX UNITY)
                else {
                    connection = (HttpURLConnection) new URL(urlStr.replace("http://", "https://")).openConnection();
                    connection.setRequestProperty("User-Agent", "Mozilla/5.0");
                    connection.setInstanceFollowRedirects(true);
                    
                    if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        // try-with-resources: mesmo motivo do bloco acima (evitar vazamento de
                        // file descriptors se a conexão cair no meio do download).
                        try (InputStream input = connection.getInputStream();
                             FileOutputStream output = new FileOutputStream(imageFile)) {
                            byte[] buffer = new byte[4096];
                            int read;
                            while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
                        }
                        if (imageFile.length() > 500) sucesso = true;
                    }
                }

                // Carrega a imagem baixada (já reduzida) e DESLIGA o loading
                if (sucesso) {
                    final Bitmap bitmap = decodificarReduzido(imageFile.getAbsolutePath(), 200, 200);
                    if (bitmap != null) memoryCache.put(titleId, bitmap);
                    mainHandler.post(() -> {
                        if (bitmap != null && imageView.getTag() != null && imageView.getTag().equals(titleId)) {
                            imageView.setImageBitmap(bitmap);
                        }
                        if (progressBar != null) progressBar.setVisibility(View.GONE);
                    });
                } else {
                    mainHandler.post(() -> {
                        if (progressBar != null) progressBar.setVisibility(View.GONE);
                    });
                }

            } catch (Exception e) {
                if (imageFile.exists()) imageFile.delete();
                e.printStackTrace();
                mainHandler.post(() -> {
                    if (progressBar != null) progressBar.setVisibility(View.GONE);
                });
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    /**
     * Decodifica um arquivo de imagem já reduzido para aproximadamente targetW x targetH,
     * em vez de carregar a imagem inteira em resolução original. Isso evita gastar memória e
     * tempo de CPU decodificando capas grandes (o Archive.org entrega imagens de capa que podem
     * ter mais de 1000px de largura) para caber num ícone pequeno de lista.
     */
    private Bitmap decodificarReduzido(String path, int targetW, int targetH) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, bounds);

            int sampleSize = 1;
            int largura = bounds.outWidth, altura = bounds.outHeight;
            while ((largura / (sampleSize * 2)) >= targetW && (altura / (sampleSize * 2)) >= targetH) {
                sampleSize *= 2;
            }

            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = sampleSize;
            return BitmapFactory.decodeFile(path, options);
        } catch (Exception e) {
            return null;
        }
    }

    public static class GameViewHolder extends RecyclerView.ViewHolder {
        ImageView imgCover;
        TextView tvName, tvTitleId, tvTipoJogo;
        ProgressBar progressLoad; // Referência para o ProgressBar da lista

        public GameViewHolder(@NonNull View itemView) {
            super(itemView);
            imgCover = itemView.findViewById(R.id.img_cover);
            tvName = itemView.findViewById(R.id.tv_game_name);
            tvTitleId = itemView.findViewById(R.id.tv_title_id);
            tvTipoJogo = itemView.findViewById(R.id.tv_tipo_jogo);
            progressLoad = itemView.findViewById(R.id.progress_load);
        }
    }
}
