package mhs.ftp.meuxbox1;

import android.content.Context;
import androidx.documentfile.provider.DocumentFile;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class XexParser {

    public static String getTitleId(Context context, DocumentFile xexFile) {
        if (xexFile == null || !xexFile.isFile()) return null;

        try (InputStream is = context.getContentResolver().openInputStream(xexFile.getUri())) {
            if (is == null) return null;

            byte[] baseHeader = new byte[0x18];
            if (lerExatamente(is, baseHeader) < 0x18) return null;

            if (baseHeader[0] != 'X' || baseHeader[1] != 'E' || baseHeader[2] != 'X' || baseHeader[3] != '2') {
                return null;
            }

            ByteBuffer bbBase = ByteBuffer.wrap(baseHeader);
            bbBase.order(ByteOrder.BIG_ENDIAN);
            int numHeaders = bbBase.getInt(0x14);

            byte[] optHeaders = new byte[numHeaders * 8];
            if (lerExatamente(is, optHeaders) < optHeaders.length) return null;

            ByteBuffer optBb = ByteBuffer.wrap(optHeaders);
            optBb.order(ByteOrder.BIG_ENDIAN);

            int offsetExecutionInfo = -1;
            for (int i = 0; i < numHeaders; i++) {
                int key = optBb.getInt();
                int value = optBb.getInt();
                if (key == 0x00040006) {
                    offsetExecutionInfo = value;
                    break;
                }
            }

            if (offsetExecutionInfo != -1) {
                int bytesJaLidos = 0x18 + (numHeaders * 8);
                int bytesParaPular = offsetExecutionInfo - bytesJaLidos;
                
                if (bytesParaPular > 0) {
                    long pulado = 0;
                    while (pulado < bytesParaPular) {
                        long p = is.skip(bytesParaPular - pulado);
                        if (p == 0) { if (is.read() == -1) break; p = 1; }
                        pulado += p;
                    }
                }

                // Só precisamos ler 16 bytes para chegar no TitleID
                byte[] execInfo = new byte[0x10]; 
                if (lerExatamente(is, execInfo) < 0x10) return null;

                ByteBuffer execBb = ByteBuffer.wrap(execInfo);
                execBb.order(ByteOrder.BIG_ENDIAN);
                
                // CORREÇÃO: O Title ID fica no offset 0x0C (12 bytes)
                int titleIdInt = execBb.getInt(0x0C); 
                return String.format("%08X", titleIdInt);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null; 
    }

    // Função de segurança para não corromper a leitura de bytes
    private static int lerExatamente(InputStream is, byte[] buffer) throws IOException {
        int lido = 0;
        while (lido < buffer.length) {
            int r = is.read(buffer, lido, buffer.length - lido);
            if (r == -1) break;
            lido += r;
        }
        return lido;
    }
}
