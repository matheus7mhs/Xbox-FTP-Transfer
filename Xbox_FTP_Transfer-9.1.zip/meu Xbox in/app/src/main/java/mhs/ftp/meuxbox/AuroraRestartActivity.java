package mhs.ftp.meuxbox1;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

/**
 * Activity usada para hospedar uma WebView de verdade, anexada a uma janela real, que faz login
 * no Aurora e clica em "Back to launcher" pra reiniciá-lo remotamente.
 *
 * MODO DEBUG_VISIVEL: enquanto estivermos ajustando os seletores/comandos, deixe DEBUG_VISIVEL=true
 * para ver a WebView na tela (tamanho normal) e receber um Toast a cada passo do processo.
 * Quando tudo estiver funcionando certinho, troque para DEBUG_VISIVEL=false para a Activity
 * voltar a ser praticamente invisível (1x1) como antes.
 */
public class AuroraRestartActivity extends Activity {

    private static final boolean DEBUG_VISIVEL = true; // <-- troque para false quando estiver tudo OK

    public static final String EXTRA_IP = "ip";
    private static final String TAG = "AuroraRestart";

    private WebView webView;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private volatile boolean respondido = false;
    private Runnable timeoutRunnable;

    private void logEMostra(String msg) {
        Log.d(TAG, msg);
        if (DEBUG_VISIVEL) {
            mainHandler.post(() -> Toast.makeText(this, msg, Toast.LENGTH_LONG).show());
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String ip = getIntent() != null ? getIntent().getStringExtra(EXTRA_IP) : null;
        if (ip == null || ip.isEmpty()) {
            logEMostra("Aurora: IP vazio, cancelando.");
            finalizarComResultado(false);
            return;
        }

        webView = new WebView(this);

        SharedPreferences prefs = getSharedPreferences("XboxPrefs", MODE_PRIVATE);
        boolean semLogin = prefs.getBoolean("aurora_sem_login", false);
        String auroraUser = prefs.getString("aurora_user", "xboxhttp");
        String auroraPass = prefs.getString("aurora_pass", "xboxhttp");

        DisplayMetrics dm = getResources().getDisplayMetrics();

        if (DEBUG_VISIVEL) {
            setContentView(webView, new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        } else {
            // IMPORTANTE: a WebView precisa de um tamanho "normal" (largura/altura reais da tela)
            // pra a página do Aurora renderizar corretamente. Um tamanho tipo 1x1 fazia o JS da
            // página achar que não tinha espaço pra desenhar os botões. Em vez de encolher a
            // WebView, jogamos a JANELA inteira pra fora da área visível da tela.
            setContentView(webView, new ViewGroup.LayoutParams(dm.widthPixels, dm.heightPixels));

            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.width = dm.widthPixels;
            lp.height = dm.heightPixels;
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.x = dm.widthPixels * 3; // bem fora da área visível
            lp.y = 0;
            getWindow().setAttributes(lp);
        }

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        String baseUrl = "http://" + ip + ":9999";
        String launcherUrl = baseUrl + "/#/launcher";

        // Enquanto depurando, dá bem mais tempo antes de desistir (a página pode estar sendo
        // observada manualmente). No modo final (oculto) volta a ser rápido.
        long timeoutMs = DEBUG_VISIVEL ? 180000 : 60000;
        timeoutRunnable = () -> {
            logEMostra("Aurora: tempo esgotado (" + (timeoutMs / 1000) + "s) sem terminar.");
            finalizarComResultado(false);
        };
        mainHandler.postDelayed(timeoutRunnable, timeoutMs);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                if (url == null) return;
                logEMostra("Página carregada: " + url);

                if (url.contains("#/login") || url.endsWith("/login")) {
                    String js = "(function(){"
                        + "var user=document.querySelector('input[type=\"text\"], input[placeholder*=\"user\"], input[name=\"username\"], input[formcontrolname=\"username\"]');"
                        + "var pass=document.querySelector('input[type=\"password\"]');"
                        + "if(user && pass){"
                        + "user.value='" + escaparJs(auroraUser) + "'; pass.value='" + escaparJs(auroraPass) + "';"
                        + "var event=new Event('input',{bubbles:true});"
                        + "user.dispatchEvent(event); pass.dispatchEvent(event);"
                        + "var btns=document.querySelectorAll('button');"
                        + "for(var i=0;i<btns.length;i++){"
                        + "if(btns[i].innerText.toLowerCase().includes('login')||btns[i].innerText.toLowerCase().includes('entrar')||btns[i].type==='submit'){"
                        + "btns[i].click(); return 'OK: campos preenchidos e botao clicado';"
                        + "}"
                        + "}"
                        + "return 'FALHOU: campos ok mas botao de login nao encontrado';"
                        + "} else { return 'FALHOU: nao achou os campos de usuario/senha'; }"
                        + "})()";
                    // Dá um tempinho pra SPA terminar de renderizar antes de mexer no DOM
                    view.postDelayed(() -> view.evaluateJavascript(js, result -> {
                        logEMostra("Login: " + result);
                        view.postDelayed(() -> view.loadUrl(launcherUrl), DEBUG_VISIVEL ? 4000 : 2000);
                    }), DEBUG_VISIVEL ? 1500 : 0);

                } else if (url.contains("#/launcher") || url.contains("/launcher")) {
                    String js = "(function(){"
                        + "var btns=document.querySelectorAll('button');"
                        + "var nomes=[];"
                        + "for(var i=0;i<btns.length;i++){ nomes.push(btns[i].innerText); }"
                        + "for(var i=0;i<btns.length;i++){"
                        + "if(btns[i].innerText.toLowerCase().includes('back to launcher')||btns[i].innerText.toLowerCase().includes('launcher')){"
                        + "btns[i].click(); return 'OK: clicou em [' + btns[i].innerText + ']';"
                        + "}"
                        + "}"
                        + "return 'FALHOU: nenhum botao bateu. Botoes na pagina: [' + nomes.join(' | ') + ']';"
                        + "})()";
                    view.postDelayed(() -> view.evaluateJavascript(js, result -> {
                        logEMostra("Launcher: " + result);
                        boolean ok = result != null && result.contains("OK");
                        if (DEBUG_VISIVEL) {
                            // Espera um pouco antes de fechar pra dar tempo de ler o Toast/tela
                            mainHandler.postDelayed(() -> finalizarComResultado(ok), 4000);
                        } else {
                            finalizarComResultado(ok);
                        }
                    }), DEBUG_VISIVEL ? 1500 : 0);
                }
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                logEMostra("Erro ao carregar " + failingUrl + ": " + errorCode + " " + description);
                if (DEBUG_VISIVEL) {
                    mainHandler.postDelayed(() -> finalizarComResultado(false), 4000);
                } else {
                    finalizarComResultado(false);
                }
            }
        });

        String urlInicial = semLogin ? launcherUrl : (baseUrl + "/#/login");
        logEMostra((semLogin ? "Abrindo launcher direto (sem login) em: " : "Abrindo login em: ") + urlInicial);
        webView.loadUrl(urlInicial);
    }

    /** Escapa aspas simples, barras invertidas e quebras de linha pra inserir um valor com
     * segurança dentro de uma string JS de aspas simples (evita quebrar o script injetado
     * se o usuário/senha do Aurora tiver algum desses caracteres). */
    private static String escaparJs(String valor) {
        if (valor == null) return "";
        return valor.replace("\\", "\\\\")
                    .replace("'", "\\'")
                    .replace("\n", "\\n")
                    .replace("\r", "");
    }

    private void finalizarComResultado(boolean ok) {
        if (respondido) return;
        respondido = true;
        mainHandler.removeCallbacks(timeoutRunnable);
        TransferService.reportarResultadoAuroraRestart(ok);
        finish();
        overridePendingTransition(0, 0);
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            try { webView.destroy(); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }
}
