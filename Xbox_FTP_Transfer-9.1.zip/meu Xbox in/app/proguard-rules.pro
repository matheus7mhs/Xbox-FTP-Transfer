# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# ===== Apache Commons Net (FTP) =====
# Adicionado como .jar solto em libs/, então NÃO traz regras próprias de ProGuard/R8
# (bibliotecas via Maven costumam trazer isso embutido no AAR, mas .jar não).
# Sem isso, o R8 pode remover/renomear partes internas usadas via reflexão pela
# biblioteca (parsers de resposta do FTP, factories de socket, etc.), fazendo o app
# se comportar de forma estranha ou travar SÓ no build de release (minificado).
-keep class org.apache.commons.net.** { *; }
-dontwarn org.apache.commons.net.**

# ===== Classes de modelo/dados do app =====
# Evita que o R8 remova campos/métodos que parecem "não usados" na análise estática
# mas são necessários (getters usados em outros pontos, construtores, etc.)
-keep class mhs.ftp.meuxbox1.ListarGames { *; }
-keep class mhs.ftp.meuxbox1.GameDatabase { *; }

# ===== WebView (reinício remoto do Aurora) =====
-keepclassmembers class mhs.ftp.meuxbox1.AuroraRestartActivity {
    public *;
}

# ===== Stack traces legíveis no Logcat mesmo em release =====
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile