
12/storage/emulated/0/AndroidIDEProjects/meu Xbox in1790438475800"�
app/build.gradleC/storage/emulated/0/AndroidIDEProjects/meu Xbox in/app/build.gradle�	 �袮�4*@bc30275808ddbfe546ca8deda5dfa25c7f3df948f7020fe69f730d32f7000950"�
build.gradle?/storage/emulated/0/AndroidIDEProjects/meu Xbox in/build.gradle� �Ӵ��4*@5a1842bab4090343acc5124d17604266928789f4bd2fd99cd171c7d73af9f95d"�
(gradle/wrapper/gradle-wrapper.properties[/storage/emulated/0/AndroidIDEProjects/meu Xbox in/gradle/wrapper/gradle-wrapper.properties� ����4*@1fb2594489a378f13816f77bf4ea6a4ac60b88d78c8c896e576f618e0710bf25"�
gradle.propertiesD/storage/emulated/0/AndroidIDEProjects/meu Xbox in/gradle.properties�
 ����4*@f57ff002734091f5749e9864d4efac062eaac73933ea93c3045a4ef7cc4ee1b7"�
local.propertiesC/storage/emulated/0/AndroidIDEProjects/meu Xbox in/local.properties! ����4*@a6680559cfdb6728b0ce30f07f880e29068c6d59dab1891929827c05a6d5b726"�
settings.gradleB/storage/emulated/0/AndroidIDEProjects/meu Xbox in/settings.gradle� ����4*@eb7297b9829a95db46628e2f1e50f1ab0f066b385a28f4827b3f071d9eaf67c0*�
M/storage/emulated/0/AndroidIDEProjects/meu Xbox in/.cg/gradle-sync/project.pb@59415e093ec44a52efaa638018d7ef142204e06fe2a4e5278c884e4880076d01