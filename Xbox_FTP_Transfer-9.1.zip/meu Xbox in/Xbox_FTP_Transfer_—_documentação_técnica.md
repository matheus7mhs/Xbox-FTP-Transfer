# Xbox FTP Transfer — documentação técnica e guia de continuidade

**Nome do projeto Gradle:** `meu Xbox `  
**Nome exibido no aplicativo:** `Xbox FTP Transfer`  
**Pacote declarado atualmente no código:** `mhs.ftp.meuxbox1`  
**Pacote/caminho físico das fontes:** `mhs/ftp/meuxbox/`  
**Versão declarada no Gradle:** `versionName "9.1"`, `versionCode 9`  
**Linguagem:** Java  
**Módulo:** `app`  
**Modelo de comunicação:** FTP pela rede local com o Xbox 360

> Este documento foi produzido a partir do conteúdo do ZIP. Apesar de o pedido mencionar o Code On The Go v26.37, o arquivo recebido contém um projeto Android Gradle tradicional, com arquivos `.cg`, `.git` e referências históricas ao AndroidIDE. A documentação considera o código efetivamente presente no ZIP.

## 1. O que o aplicativo faz

O projeto é uma evolução do aplicativo MeuXbox para transferência de jogos ao Xbox 360 por **FTP**, sem usar USB OTG diretamente no celular.

O celular e o Xbox precisam estar na mesma rede, ou o endereço do Xbox precisa ser alcançável pelo telefone. O app:

- conecta ao Xbox usando IP, porta, usuário e senha FTP;
- permite selecionar uma pasta local do celular pelo Storage Access Framework;
- identifica jogos XEX por `default.xex` e extrai o Title ID;
- identifica pacotes STFS/GOD por cabeçalho `CON `, `PIRS` ou `LIVE`;
- copia XEX para `Games/` ou `Apps/`;
- copia GOD/STFS para a estrutura `Content/0000000000000000/<TitleID>/...`;
- evita reenviar arquivos cujo tamanho remoto já é igual ao tamanho local;
- mantém a transferência em foreground service, com notificação;
- possui fila de múltiplos jogos;
- permite pausar, retomar e cancelar;
- tenta reconectar quando a rede ou o Xbox falham;
- pode pedir ao usuário para reiniciar o Aurora remotamente depois de várias falhas;
- cataloga jogos instalados nos caminhos `Hdd1`, `Usb0`, `Usb1` e `Usb2`;
- identifica jogos GOD, XEX e XBLA;
- baixa e armazena capas de jogos;
- calcula o tamanho do jogo, DLCs, saves e Title Updates;
- lista conteúdos extras e permite desinstalar somente o jogo ou o jogo mais extras;
- guarda o último catálogo em cache local por endereço IP;
- possui traduções em vários idiomas.

## 2. Arquitetura do projeto

```mermaid
flowchart TD
    A[MainActivity\nTela principal] --> B[TransferService\nFTP, fila e progresso]
    A --> C[MeusJogosFragment\nCatálogo remoto]
    A --> D[AuroraRestartActivity\nWebView remoto]
    B --> E[Apache Commons Net\nFTPClient]
    B --> F[XexParser / cabeçalho STFS]
    C --> E
    C --> G[GameCache\nJSON local]
    C --> H[GameAdapter\nRecyclerView]
    H --> I[GameDatabase\njogos.csv]
    A --> J[DocumentFile/SAF\norigem local]
    A --> K[Capas online\nXboxUnity/Archive.org]
```

### Fluxo de transferência

1. O usuário digita o IP do Xbox, escolhe `Hdd1`, `Usb0` ou `Usb1` e testa a conexão.
2. O app salva IP e configurações FTP em `SharedPreferences`.
3. O usuário toca em **Selecionar Pasta**.
4. O Android abre `ACTION_OPEN_DOCUMENT_TREE` e o usuário seleciona a pasta raiz do jogo.
5. `MainActivity` procura arquivos `.xex` até uma profundidade limitada.
6. Se encontrar XEX, `XexParser` tenta obter o Title ID e o usuário escolhe `Games` ou `Apps`.
7. Se não for XEX, `TransferService` analisa cabeçalhos STFS e decide os caminhos `Content`.
8. O serviço cria uma lista de tarefas FTP, conecta ao Xbox e transfere uma tarefa por vez.
9. A tela recebe callbacks de status, arquivo atual, progresso, jogo atual e fila.
10. Em caso de falha, o arquivo em andamento volta a ser tentado. Depois de cinco falhas consecutivas, o app pode solicitar o reinício do Aurora.
11. Ao concluir um XEX com Title ID, o serviço grava um marcador `mhs_id_<TitleID>.txt` na pasta remota para acelerar futuras catalogações.

### Fluxo do catálogo

1. `MeusJogosFragment` recupera o IP e as credenciais nas preferências.
2. Se houver cache para aquele IP, ele é exibido imediatamente.
3. Ao escanear, o fragmento conecta via FTP e percorre:
   - `Hdd1/Content/0000000000000000`;
   - `Usb0/Content/0000000000000000`;
   - `Usb1/Content/0000000000000000`;
   - `Usb2/Content/0000000000000000`.
4. Procura jogos GOD em `00007000`, jogos XBLA em `000D0000`/`000D0001` e pastas XEX em profundidade máxima de dois níveis.
5. `GameDatabase` converte Title IDs conhecidos em nomes.
6. `GameAdapter` apresenta a biblioteca e carrega capas usando cache de memória e disco.
7. O resultado é salvo em JSON por IP.

## 3. Estrutura de diretórios

```text
meu Xbox in/
├── build.gradle
├── settings.gradle
├── gradle.properties
├── local.properties              # caminho local do SDK; não deve ser versionado
├── gradlew / gradlew.bat
├── gradle/wrapper/               # Gradle Wrapper 8.13
├── .git/                         # histórico incluído no ZIP
├── .cg/                          # estado do Code On The Go/ambiente de edição
├── build/ e .gradle/             # artefatos gerados; não são código-fonte
└── app/
    ├── build.gradle
    ├── proguard-rules.pro
    ├── libs/commons-net-3.9.0.jar
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/mhs/ftp/meuxbox/
        ├── res/
        ├── assets/jogos.csv
        └── play_store_512.png
```

### Atenção ao pacote Java

O caminho físico das fontes é `app/src/main/java/mhs/ftp/meuxbox/`, mas todas as classes declaram:

```java
package mhs.ftp.meuxbox1;
```

Isso é permitido pelo compilador porque o caminho físico pode divergir, mas é confuso para manutenção. O `namespace`, o `applicationId` e o atributo `package` do Manifest também usam `mhs.ftp.meuxbox1`. Ao reorganizar no Android Studio, mantenha todos consistentes. A opção recomendada é mover as fontes para:

```text
app/src/main/java/mhs/ftp/meuxbox1/
```

ou, alternativamente, alterar todos os `package` para `mhs.ftp.meuxbox` e também alterar `namespace`, `applicationId` e Manifest. Não faça apenas uma dessas alterações.

## 4. Classes Java

Todas ficam em `app/src/main/java/mhs/ftp/meuxbox/`, embora declarem o pacote Java `mhs.ftp.meuxbox1`.

### `MainActivity.java`

É a tela principal e o ponto de entrada do aplicativo.

Responsabilidades:

- carregar `activity_main.xml`;
- inicializar `GameDatabase`;
- carregar o último IP salvo;
- pedir a permissão de notificações no Android 13+;
- abrir o seletor de pasta local;
- detectar XEX e escolher `Games`/`Apps`;
- iniciar e vincular o `TransferService`;
- repassar jogos para a fila;
- exibir progresso individual e total;
- testar conexão FTP;
- mostrar a capa e o nome do jogo atual;
- abrir `MeusJogosFragment`;
- abrir tutorial/configurações/créditos;
- salvar usuário, senha, porta FTP e configurações do Aurora.

O método `onActivityResult()` recebe a pasta selecionada pelo SAF e tenta manter a permissão persistente usando `takePersistableUriPermission()`.

A busca de XEX é limitada a quatro níveis (`depth > 3`) para evitar uma varredura excessivamente lenta. O `default.xex` é usado pelo `XexParser` para obter o Title ID.

### `TransferService.java`

É o núcleo da transferência. É um `Service` iniciado como foreground service.

Principais responsabilidades:

- manter a fila `ConcurrentLinkedQueue<TransferJob>`;
- processar jogos um por vez;
- criar uma lista de `FtpTask` para arquivos e diretórios;
- mapear XEX recursivamente;
- analisar pacotes STFS/GOD;
- criar diretórios remotos via FTP;
- conectar usando `FTPClient` do Apache Commons Net;
- enviar arquivos com `storeFile()`;
- consultar tamanho remoto usando o comando FTP `SIZE`;
- pular o arquivo se o tamanho remoto for igual ao local;
- substituir arquivo existente quando os tamanhos forem diferentes;
- atualizar progresso individual/total;
- pausar e retomar a leitura do arquivo com `pauseLock`;
- cancelar transferência e limpar a fila;
- tentar novamente em falhas de conexão;
- manter notificação de progresso;
- chamar o reinício do Aurora após cinco falhas consecutivas;
- salvar `mhs_id_<TitleID>.txt` em jogos XEX quando o Title ID for conhecido.

Configurações relevantes:

- timeout de conexão: 30 segundos;
- timeout de controle: 60 segundos;
- timeout de dados: 15 minutos;
- limite geral de falhas consecutivas: 60;
- reinício do Aurora avaliado a cada 5 falhas;
- após reiniciar Aurora com sucesso, aguarda 20 segundos antes de continuar.

A fila não é persistida em banco/arquivo. Se o processo for morto pelo Android, a fila em memória pode ser perdida.

### `AuroraRestartActivity.java`

Hospeda uma `WebView` real para acessar a interface HTTP do Aurora no Xbox, em:

```text
http://<IP>:9999
```

Com login normal, abre `/#/login`, preenche usuário e senha via JavaScript, depois navega para `/#/launcher` e procura um botão contendo `launcher` ou `back to launcher`.

Com a opção sem login, abre o launcher diretamente.

O resultado é devolvido ao `TransferService` por `TransferService.reportarResultadoAuroraRestart(boolean)`.

**Importante:** `DEBUG_VISIVEL` está `true` no arquivo recebido. Assim, a WebView aparece na tela e exibe Toasts. Para produção, depois de testar os seletores, avaliar mudar para `false`.

### `MeusJogosFragment.java`

Implementa o catálogo remoto.

Funções principais:

- carregar catálogo do `GameCache`;
- conectar por FTP;
- escanear GOD, XEX e XBLA;
- calcular número responsivo de colunas usando `dimens.xml`;
- manter a UI segura quando o fragmento é fechado durante uma thread de escaneamento;
- ler cabeçalhos STFS diretamente pelo FTP para identificar XBLA;
- extrair Title ID de `default.xex` sem salvar o arquivo no celular;
- calcular o tamanho do jogo e dos extras;
- listar DLC, saves e Title Updates;
- desinstalar jogo ou jogo mais conteúdos associados.

Tipos de conteúdo usados:

- `00000001`: saves;
- `00000002`: DLC/Marketplace Content;
- `000B0000`: Title Updates;
- `00007000`: jogo GOD;
- `000D0000` e `000D0001`: jogos Arcade/XBLA.

O escaneamento XEX ignora diretórios de sistema como `Content`, `Cache`, `SysCache`, `Aurora`, `Plugins`, `DashLaunch` e outros para reduzir falsos positivos.

### `GameAdapter.java`

Adapter do `RecyclerView` do catálogo.

- mostra capa, nome, Title ID e tipo (`GOD`, `XEX` ou `XBLA`);
- abre diálogo de detalhes;
- calcula tamanho total em thread separada;
- lista DLC/saves/TU;
- abre confirmação de desinstalação;
- usa executor compartilhado com quatro threads;
- usa `LruCache` para imagens;
- usa cache em disco para capas;
- reduz a resolução das imagens antes de criar o Bitmap.

As capas são procuradas primeiro no cache e depois baixadas de URLs externas. O primeiro endpoint usa XboxUnity em HTTP e o diálogo de detalhes usa diretório de capas do Archive.org.

### `GameCache.java`

Salva e carrega o último catálogo por IP em:

```text
Context.getFilesDir()/game_cache/scan_<IP_sanitizado>.json
```

O JSON armazena timestamp, Title ID, nome, caminho FTP e tipo de jogo. É um cache best-effort: se estiver corrompido ou ausente, o app faz novo escaneamento.

### `GameDatabase.java`

Carrega `assets/jogos.csv` uma única vez e cria um mapa:

```text
TITLE_ID,nome do jogo
```

Se o ID não estiver cadastrado, retorna `ID: <TitleID>`. Se não houver banco carregado, mostra `Desconhecido`.

O parser divide apenas na primeira vírgula (`split(",", 2)`), permitindo vírgulas no nome depois da primeira coluna.

### `ListarGames.java`

Modelo de dados do catálogo:

- `titleId`: identificador hexadecimal do jogo;
- `nome`: nome amigável;
- `coverUrl`: URL calculada da capa;
- `caminhoFtp`: caminho remoto;
- `tipoJogo`: `GOD`, `XEX` ou `XBLA`.

### `XexParser.java`

Lê `default.xex` pelo SAF. Ele:

1. valida a assinatura `XEX2`;
2. lê o número de headers opcionais;
3. procura o header `0x00040006` de informações de execução;
4. salta até a estrutura de execução;
5. lê o Title ID no deslocamento `0x0C` em ordem Big Endian;
6. retorna o ID com oito caracteres hexadecimais.

### `GameDatabase`, `GameCache`, modelos e recursos

Essas classes não fazem comunicação direta com o Xbox. Elas sustentam o catálogo, os nomes, os caches e a apresentação da informação.

## 5. Manifesto, permissões e conectividade

`AndroidManifest.xml` declara:

- `INTERNET`: FTP e download de capas;
- `ACCESS_NETWORK_STATE`: estado da rede;
- `FOREGROUND_SERVICE`: transferência em segundo plano;
- `POST_NOTIFICATIONS`: notificação no Android 13+;
- `READ_EXTERNAL_STORAGE`: declarado, mas a origem usa principalmente SAF;
- `MANAGE_EXTERNAL_STORAGE`: permissão de alto impacto que merece revisão;
- `MainActivity`: activity launcher;
- `AuroraRestartActivity`: activity interna, fora da lista de recentes;
- `TransferService`: foreground service com `dataSync`.

A aplicação também tem:

```xml
android:usesCleartextTraffic="true"
android:networkSecurityConfig="@xml/network_security_config"
```

Isso permite HTTP não criptografado. É necessário para o endpoint HTTP do Aurora e para o endpoint HTTP de capa usado no código, mas reduz a segurança. Quando possível, trocar para HTTPS ou restringir cleartext apenas aos hosts realmente necessários.

## 6. Recursos e layouts

### Layouts principais

| Arquivo | Função |
|---|---|
| `activity_main.xml` | Tela de IP, destino, teste de conexão, seleção de pasta, progresso, fila, pausa, cancelamento e jogo atual. |
| `fragment_meus_jogos.xml` | Botão de escaneamento, status e `RecyclerView` do catálogo. |
| `item_game.xml` | Cartão com capa, nome, Title ID e tipo do jogo. |
| `dialog_detalhes.xml` | Capa ampliada, caminho FTP, Title ID, tamanho, extras e desinstalação. |
| `dialog_lista_conteudo.xml` | Lista de DLC, saves e Title Updates. |
| `dialog_desinstalar.xml` | Escolha entre remover só o jogo ou também os extras. |
| `dialog_info_creditos.xml` | Configuração FTP, configuração Aurora e créditos. |
| `dialog_creditos.xml` | Conteúdo auxiliar de créditos. |
| `dialog_tutorial.xml` | Tutorial inicial. |

### Drawables, tema e dimensões

- `bg_button_primary.xml`: botão principal verde;
- `bg_button_secondary.xml`: botão secundário;
- `bg_card_highlight.xml`: destaque de cartões;
- `bg_input_field.xml`: campo de entrada;
- `ic_folder.xml`, `ic_gamepad.xml`, `ic_info.xml`, `ic_network.xml`: ícones;
- `ic_ftp*`: ícone adaptativo do aplicativo;
- `colors.xml` e `values-night/colors.xml`: cores claro/escuro;
- `themes.xml`: temas Material;
- `dimens.xml`, `values-sw600dp/dimens.xml`, `values-sw840dp/dimens.xml`: tamanhos responsivos;
- `backup_rules.xml` e `data_extraction_rules.xml`: comportamento de backup;
- `network_security_config.xml`: permite tráfego cleartext.

### Traduções

Existem diretórios `values-*` para português, inglês, espanhol, francês e vários outros idiomas. Ao adicionar uma string nova, inserir no `values/strings.xml` e atualizar as traduções que serão distribuídas.

### Assets e áudio

- `assets/jogos.csv`: mapa de Title IDs;
- `play_store_512.png`: ícone de publicação;
- `res/raw/erro.mp3`: som de falha;
- `res/raw/sucesso.mp3`: som de sucesso.

## 7. Gradle e dependências

### Configuração do aplicativo

Em `app/build.gradle`:

- Android Gradle Plugin: `8.11.0`;
- Gradle Wrapper: `8.13`;
- `namespace`: `mhs.ftp.meuxbox1`;
- `applicationId`: `mhs.ftp.meuxbox1`;
- `compileSdk`: 36;
- `targetSdk`: 36;
- `minSdk`: 24;
- Java 17;
- `viewBinding: true`;
- release minificado com R8/ProGuard.

Dependências Maven:

- AppCompat `1.6.1`;
- Material `1.9.0`;
- ConstraintLayout `2.1.4`;
- DocumentFile `1.0.1`;
- RecyclerView `1.3.0`;
- CardView `1.0.0`.

Dependência local:

```text
app/libs/commons-net-3.9.0.jar
```

Esse JAR fornece `org.apache.commons.net.ftp.FTPClient`, usado no envio, escaneamento, cálculo de tamanho e exclusão.

### `proguard-rules.pro`

Mantém classes do Apache Commons Net, modelos e `GameDatabase`, preserva membros de `AuroraRestartActivity` e mantém nomes de arquivo/linha nos stack traces.

Ao adicionar bibliotecas via `.jar`, verificar se elas precisam de regras `-keep`. JARs locais não fornecem automaticamente regras R8 como algumas bibliotecas Maven fazem.

## 8. Preferências salvas e segurança

As configurações ficam em `SharedPreferences` com o nome `XboxPrefs`.

Chaves observadas:

| Chave | Uso |
|---|---|
| `last_ip` | Último IP do Xbox. |
| `ftp_user` / `ftp_pass` | Credenciais FTP. |
| `ftp_port` | Porta FTP, padrão 21. |
| `aurora_user` / `aurora_pass` | Credenciais HTTP do Aurora. |
| `aurora_sem_login` | Abre Aurora sem login. |
| `aurora_auto_restart` | Permite reinício automático após falhas. |
| `primeiro_uso` | Controla exibição do tutorial inicial. |

As senhas são salvas em texto recuperável nas preferências do aplicativo e também são inseridas em JavaScript da WebView. Para uma versão de distribuição, considerar:

- Android Keystore/EncryptedSharedPreferences;
- não exibir senha em logs;
- usar HTTPS para Aurora quando suportado;
- limpar credenciais quando o usuário sair;
- avisar que FTP e HTTP cleartext expõem credenciais na rede local;
- revisar se `MANAGE_EXTERNAL_STORAGE` é realmente necessário.

## 9. Como abrir/converter para Android Studio

O projeto já contém `settings.gradle`, `build.gradle`, `gradlew` e um módulo Android. Portanto, a conversão consiste principalmente em abrir, corrigir o caminho do SDK e organizar o pacote.

### Pré-requisitos

- Android Studio atualizado;
- JDK 17;
- Android SDK Platform 36;
- Build-Tools compatível;
- conexão de rede para o Gradle baixar dependências Maven;
- um Xbox 360 com servidor FTP ativo e acessível pela mesma rede para o teste funcional.

### Passo a passo

1. Extraia o ZIP para uma pasta sem necessidade de manter o nome com espaços. Exemplo:

   ```text
   C:\Projetos\MeuXboxFTP\
   ```

2. Remova ou não reutilize `local.properties` do ZIP. Ele aponta para um caminho específico de outra máquina:

   ```text
   sdk.dir=/home/ubuntu/android-sdk
   ```

3. Abra o Android Studio e escolha **Open** / **Open an Existing Project**.
4. Selecione a raiz que contém `settings.gradle`, não apenas `app`.
5. Aguarde a sincronização.
6. Em **Settings > Build, Execution, Deployment > Build Tools > Gradle**, selecione JDK 17.
7. No **SDK Manager**, instale Android API 36 e Build-Tools recomendados.
8. Confirme que o Android Studio reconheceu o módulo `app`.
9. Se o IDE pedir para atualizar Gradle/AGP, faça uma cópia antes. O ZIP já usa AGP 8.11.0 e Gradle 8.13; atualizar pode exigir ajustes.
10. Corrija a organização do pacote Java, se desejado:
    - opção A: mover as fontes para `mhs/ftp/meuxbox1/` e manter os packages atuais;
    - opção B: alterar os `package` para `mhs.ftp.meuxbox` e sincronizar `namespace`, `applicationId` e Manifest.
11. Execute **Build > Make Project**.
12. Execute o aplicativo em um telefone Android para validar a interface. O teste do FTP deve ser feito em uma rede com Xbox real.

### Correção recomendada de pacote

A forma mais simples e menos invasiva é mover as fontes:

```bash
mkdir -p app/src/main/java/mhs/ftp/meuxbox1
mv app/src/main/java/mhs/ftp/meuxbox/*.java app/src/main/java/mhs/ftp/meuxbox1/
```

Depois, remover a pasta vazia antiga e manter:

```gradle
namespace 'mhs.ftp.meuxbox1'
applicationId "mhs.ftp.meuxbox1"
```

O Manifest já usa `mhs.ftp.meuxbox1`.

No Windows, faça a movimentação pelo Android Studio usando **Refactor > Rename** ou **Move**, para que imports e referências sejam atualizados com segurança.

### Configurar o SDK

O Android Studio criará um novo `local.properties`. Exemplo Linux:

```properties
sdk.dir=/home/usuario/Android/Sdk
```

Exemplo Windows, usando barras escapadas ou caminho aceito pelo Gradle:

```properties
sdk.dir=C:\\Users\\Usuario\\AppData\\Local\\Android\\Sdk
```

Não committe `local.properties`.

### Compilar pela linha de comando

Linux/macOS:

```bash
cd "meu Xbox in"
chmod +x gradlew
./gradlew :app:assembleDebug
```

Windows:

```powershell
cd "meu Xbox in"
.\gradlew.bat :app:assembleDebug
```

Saída esperada:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Instalação via ADB:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## 10. Como testar o aplicativo

### Teste básico de conexão

1. Ative o FTP no Xbox/Aurora.
2. Descubra o IP do Xbox.
3. Confirme usuário e senha FTP.
4. No app, informe IP e destino.
5. Toque em **Testar Conexão**.
6. Confirme a mensagem de sucesso.
7. Se `Usb1` estiver acessível, verifique se o botão aparece.

### Teste de envio XEX

1. Selecione uma pasta que contenha `default.xex`.
2. Confirme a identificação do Title ID.
3. Escolha `Games` ou `Apps`.
4. Observe a notificação e as barras de progresso.
5. Teste pausar e retomar.
6. Selecione mais de um jogo para testar a fila.
7. Cancele um teste controlado e confirme que a fila é limpa.
8. Repita o envio para verificar se arquivos de mesmo tamanho são pulados.

### Teste de GOD/STFS/XBLA

- selecione uma pasta GOD;
- confirme a criação em `Content/0000000000000000/<TitleID>/00007000`;
- teste DLC e pacotes STFS;
- teste um jogo XBLA em `000D0000`;
- confirme que o catálogo identifica o tipo correto.

### Teste do Aurora

Simule várias falhas de conexão ou um Aurora que não responde. Após cinco falhas consecutivas:

1. confirme a caixa de decisão;
2. escolha reiniciar uma vez ou sempre;
3. valide a WebView, login e botão de retorno ao launcher;
4. confirme que a transferência continua depois do intervalo de 20 segundos.

Esse teste deve ser feito com cópia de arquivos não críticos.

### Teste do catálogo

- abra **Meus Jogos** sem cache;
- verifique o escaneamento remoto;
- feche e reabra para validar o cache;
- toque em um jogo e confira tamanho;
- liste DLC/saves/TU;
- teste a exclusão apenas do jogo;
- teste a exclusão de jogo + extras somente após fazer backup.

## 11. Limitações e riscos encontrados

1. **Build no sandbox:** o projeto não compilou no ambiente analisado porque `local.properties` aponta para `/home/ubuntu/android-sdk`, diretório inexistente. Com JDK 17, o Gradle identificou diretamente a ausência do SDK. Isso deve ser corrigido no Android Studio.
2. **Inconsistência de caminho/pacote:** as fontes estão fisicamente em `mhs/ftp/meuxbox`, mas declaram `mhs.ftp.meuxbox1`. Organizar antes de uma manutenção maior.
3. **`local.properties` específico de máquina:** deve ser removido do controle de versão e recriado por cada desenvolvedor.
4. **FTP/HTTP sem criptografia:** credenciais e arquivos podem trafegar em cleartext. O projeto permite isso explicitamente no Manifest e na configuração de segurança.
5. **Credenciais em SharedPreferences:** usuário e senha FTP/Aurora são armazenados sem proteção criptográfica dedicada.
6. **Permissão `MANAGE_EXTERNAL_STORAGE`:** é poderosa e pode ser rejeitada pela Play Store; o app usa SAF para escolher pastas, então avaliar se essa permissão é necessária.
7. **Reinício Aurora dependente de HTML:** a automação procura textos e elementos HTML específicos. Uma atualização do Aurora pode quebrar os seletores.
8. **Fila em memória:** matar o processo perde fila e estado da transferência.
9. **Reinício remoto é destrutivo para a sessão:** deve ser opcional e sempre testado no hardware correto.
10. **Exclusão recursiva:** a desinstalação remove arquivos diretamente via FTP e não possui lixeira.
11. **Capas externas:** a biblioteca continua funcional sem capa, mas URLs podem mudar ou ficar indisponíveis.
12. **Código duplicado de busca de Title ID:** há parsing em `XexParser`, em `TransferService` e em `MeusJogosFragment`. Uma futura refatoração deve centralizar esse parser.
13. **README ausente no estado de trabalho:** o histórico Git contém um README no commit anterior, mas o arquivo aparece removido no estado atual do ZIP. Recomenda-se recuperar ou substituir por esta documentação.
14. **`DEBUG_VISIVEL = true`:** a activity de reinício do Aurora está em modo de depuração visível.
15. **Versão:** o ZIP chama-se `10.3`, mas o Gradle declara `versionName 9.1`. Definir uma convenção e atualizar `versionName`, changelog e documentação antes de publicar.

## 12. Checklist para quem continuar o projeto

- [ ] remover `local.properties` do repositório;
- [ ] configurar SDK 36 no Android Studio;
- [ ] configurar JDK 17;
- [ ] corrigir o caminho/pacote `mhs.ftp.meuxbox` versus `mhs.ftp.meuxbox1`;
- [ ] compilar `assembleDebug`;
- [ ] testar conexão FTP com Xbox real;
- [ ] confirmar IP, porta, usuário e senha;
- [ ] revisar armazenamento seguro das credenciais;
- [ ] revisar necessidade de `MANAGE_EXTERNAL_STORAGE`;
- [ ] testar XEX, GOD e XBLA;
- [ ] testar fila, pausa, retomada e cancelamento;
- [ ] testar reconexão e reinício Aurora;
- [ ] testar catálogo, cache, capas e desinstalação;
- [ ] mudar `DEBUG_VISIVEL` para `false` somente depois de validar a automação;
- [ ] revisar URLs HTTP/HTTPS e política de privacidade;
- [ ] atualizar a versão do Gradle;
- [ ] gerar APK/AAB somente depois dos testes de rede e exclusão;
- [ ] manter esta documentação junto do projeto.
